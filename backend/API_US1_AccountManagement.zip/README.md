# US1

US1 - Account Management: authentication, account CRUD and role management.

Project path: `backend/SmartBusTicketing.Api/`
This ZIP is a self-contained copy of the current API structure with the selected User Story controllers.
