-- 1. Thêm dữ liệu mẫu Người dùng (Đủ 5 vai trò)
INSERT INTO users (username, password, name, role, status) VALUES
('admin', '123456', 'Nguyễn Văn Admin', 'ADMIN', 'ACTIVE'),
('manager01', '123456', 'Trần Thị Quản Lý', 'MANAGER', 'ACTIVE'),
('driver01', '123456', 'Lê Văn Tài Xế', 'DRIVER', 'ACTIVE'),
('passenger01', '123456', 'Khánh Huy Hành Khách', 'PASSENGER', 'ACTIVE'),
('conductor01', '123456', 'Phạm Văn Phụ Xe', 'CONDUCTOR', 'ACTIVE');

-- 2. Thêm Tuyến đường
INSERT INTO routes (route_code, route_name, start_location, end_location) VALUES
('BUS-01', 'Tuyến 01: Bến xe Mỹ Đình - Bến xe Giáp Bát', 'Bến xe Mỹ Đình', 'Bến xe Giáp Bát'),
('BUS-02', 'Tuyến 02: Bến xe Yên Nghĩa - Bến xe Gia Lâm', 'Bến xe Yên Nghĩa', 'Bến xe Gia Lâm');

-- 3. Thêm Trạm dừng
INSERT INTO bus_stops (stop_name, address) VALUES
('Trạm Mỹ Đình', 'Phạm Hùng, Nam Từ Liêm, Hà Nội'),
('Trạm Cầu Giấy', 'Đường Cầu Giấy, Cầu Giấy, Hà Nội'),
('Trạm Giáp Bát', 'Giải Phóng, Hoàng Mai, Hà Nội');

-- 4. Gán trạm vào tuyến (Theo thứ tự)
INSERT INTO route_stops (route_id, stop_id, stop_order) VALUES
(1, 1, 1),
(1, 2, 2),
(1, 3, 3);

-- 5. Thêm Giá vé
INSERT INTO fares (route_id, ticket_type, price) VALUES
(1, 'VE_LUOT', 7000.00),
(1, 'VE_THANG', 100000.00),
(2, 'VE_LUOT', 8000.00);

-- 6. Thêm Phản ánh mẫu
INSERT INTO feedbacks (passenger_id, route_id, content, rating, status) VALUES
(4, 1, 'Xe chạy đúng giờ, tài xế thái độ lịch sự.', 5, 'DA_XU_LY'),
(4, 2, 'Điều hòa trên xe bị hỏng, rất nóng.', 2, 'CHUA_XU_LY');

-- 7. Thêm Nhật ký mẫu
INSERT INTO audit_logs (user_id, action, description, ip_address) VALUES
(1, 'LOGIN', 'Admin đăng nhập hệ thống thành công', '127.0.0.1'),
(2, 'CREATE_ROUTE', 'Thêm mới Tuyến 02', '127.0.0.1');