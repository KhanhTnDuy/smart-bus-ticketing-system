-- =============================================
-- 1. BẢNG TÀI KHỎAN & PHÂN QUYỀN (User Story 1)
-- =============================================
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL, -- 'ADMIN', 'MANAGER', 'DRIVER', 'PASSENGER', 'CONDUCTOR'
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE', -- 'ACTIVE', 'INACTIVE'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =============================================
-- 2. BẢNG NHẬT KÝ HỆ THỐNG (User Story 2)
-- =============================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT,
    action VARCHAR(100) NOT NULL, -- 'LOGIN', 'CREATE_USER', 'UPDATE_ROUTE',...
    description TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- 3. QUẢN LÝ TUYẾN, TRẠM, GIÁ VÉ (User Story 3)
-- =============================================
-- Bảng Tuyến đường
CREATE TABLE IF NOT EXISTS routes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    route_code VARCHAR(20) NOT NULL UNIQUE, -- VD: 'BUS-01'
    route_name VARCHAR(150) NOT NULL,      -- VD: 'Bến xe Mỹ Đình - Bến xe Giáp Bát'
    start_location VARCHAR(150) NOT NULL,
    end_location VARCHAR(150) NOT NULL,
    status VARCHAR(20) DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bảng Trạm dừng
CREATE TABLE IF NOT EXISTS bus_stops (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    stop_name VARCHAR(150) NOT NULL,
    address VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8)
);

-- Bảng Liên kết Tuyến - Trạm (Sắp xếp thứ tự trạm dừng)
CREATE TABLE IF NOT EXISTS route_stops (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    route_id BIGINT NOT NULL,
    stop_id BIGINT NOT NULL,
    stop_order INT NOT NULL, -- Thứ tự trạm dừng (1, 2, 3...)
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE,
    FOREIGN KEY (stop_id) REFERENCES bus_stops(id) ON DELETE CASCADE
);

-- Bảng Giá vé
CREATE TABLE IF NOT EXISTS fares (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    route_id BIGINT NOT NULL,
    ticket_type VARCHAR(50) NOT NULL, -- 'VE_LUOT', 'VE_THANG', 'VE_UU_TIEN'
    price DECIMAL(12, 2) NOT NULL,    -- Chuẩn BigDecimal chống lỗi số thực
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE
);

-- =============================================
-- 4. BẢNG PHẢN ÁNH & ĐÁNH GIÁ (User Story 4)
-- =============================================
CREATE TABLE IF NOT EXISTS feedbacks (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    passenger_id BIGINT NOT NULL,
    route_id BIGINT,
    content TEXT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    status VARCHAR(30) NOT NULL DEFAULT 'CHUA_XU_LY', -- 'CHUA_XU_LY', 'DANG_XU_LY', 'DA_XU_LY'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (passenger_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE SET NULL
);