import type { AuditLog } from '../types';

const API_URL = import.meta.env.VITE_API_URL ?? 'https://localhost:7053';

type AuditQuery = {
  search?: string;
  module?: string;
  status?: string;
  date?: string;
};

export async function getAuditLogs(query: AuditQuery, role = 'ADMIN'): Promise<AuditLog[]> {
  const params = new URLSearchParams();
  if (query.search) params.set('search', query.search);
  if (query.module && query.module !== 'ALL') params.set('module', query.module);
  if (query.status && query.status !== 'ALL') params.set('status', query.status);
  if (query.date) params.set('date', query.date);

  const response = await fetch(`${API_URL}/api/audit-logs?${params.toString()}`, {
    headers: { 'X-User-Role': role },
  });

  if (!response.ok) throw new Error(`Audit API error: ${response.status}`);
  return response.json();
}

export async function seedAuditDemo(role = 'ADMIN'): Promise<void> {
  const response = await fetch(`${API_URL}/api/audit-logs/seed-demo`, {
    method: 'POST',
    headers: { 'X-User-Role': role },
  });
  if (!response.ok) throw new Error(`Seed API error: ${response.status}`);
}
