# Kết nối AuditLogPage với US2 API

1. Copy `auditLogApi.ts` vào `frontend/src/services/`.
2. Đổi import type trong file thành:
   `import type { AuditLog } from '../types';`
3. Trong `DataContext.tsx`, import `getAuditLogs`.
4. Thêm `useEffect` gọi `getAuditLogs({}, currentUser?.role ?? 'ADMIN')` rồi `setAuditLogs(data)`.
5. Trong `addAuditLog`, sau khi tạo log local, gọi POST `/api/audit-logs` nếu muốn các thao tác từ frontend được lưu thật vào MySQL.
6. Tạo `.env` ở frontend:
   `VITE_API_URL=https://localhost:7001`
   hoặc URL backend mà Visual Studio in ra khi chạy.

AuditLogPage.tsx không cần đổi giao diện. Các field API trả về đã khớp với `AuditLog` của frontend: id, user, action, module, description, dateTime, status, ipAddress, targetId, details.
