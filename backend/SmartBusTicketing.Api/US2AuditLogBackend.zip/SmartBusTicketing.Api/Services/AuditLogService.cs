using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.DTOs;
using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.Services;

public interface IAuditLogService
{
    Task<List<AuditLogDto>> GetLogsAsync(string? search, string? module, string? status, DateTime? date);
    Task<AuditLogDto?> GetByIdAsync(long id);
    Task<AuditLogDto> CreateAsync(CreateAuditLogRequest request);
    Task SeedDemoDataAsync();
}

public class AuditLogService : IAuditLogService
{
    private readonly AppDbContext _db;

    public AuditLogService(AppDbContext db) => _db = db;

    public async Task<List<AuditLogDto>> GetLogsAsync(string? search, string? module, string? status, DateTime? date)
    {
        var query = _db.AuditLogs.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var value = search.Trim();
            query = query.Where(x =>
                x.Username.Contains(value) ||
                x.Action.Contains(value) ||
                (x.Details != null && x.Details.Contains(value)) ||
                (x.TargetResource != null && x.TargetResource.Contains(value)) ||
                x.Id.ToString().Contains(value));
        }

        if (!string.IsNullOrWhiteSpace(module) && !module.Equals("ALL", StringComparison.OrdinalIgnoreCase) &&
            Enum.TryParse<AuditModule>(module, true, out var parsedModule))
        {
            query = query.Where(x => x.Module == parsedModule);
        }

        if (!string.IsNullOrWhiteSpace(status) && !status.Equals("ALL", StringComparison.OrdinalIgnoreCase) &&
            Enum.TryParse<AuditStatus>(status, true, out var parsedStatus))
        {
            query = query.Where(x => x.Status == parsedStatus);
        }

        if (date.HasValue)
        {
            var from = date.Value.Date;
            var to = from.AddDays(1);
            query = query.Where(x => x.CreatedAt >= from && x.CreatedAt < to);
        }

        var logs = await query.OrderByDescending(x => x.CreatedAt).ToListAsync();
        return logs.Select(ToDto).ToList();
    }

    public async Task<AuditLogDto?> GetByIdAsync(long id)
    {
        var log = await _db.AuditLogs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return log == null ? null : ToDto(log);
    }

    public async Task<AuditLogDto> CreateAsync(CreateAuditLogRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Username))
            throw new ArgumentException("Username is required.");
        if (string.IsNullOrWhiteSpace(request.Action))
            throw new ArgumentException("Action is required.");
        if (!Enum.TryParse<AuditActionType>(request.ActionType, true, out var actionType))
            throw new ArgumentException("ActionType không hợp lệ.");
        if (!Enum.TryParse<AuditModule>(request.Module, true, out var module))
            throw new ArgumentException("Module không hợp lệ.");
        if (!Enum.TryParse<AuditStatus>(request.Status, true, out var status))
            throw new ArgumentException("Status không hợp lệ.");

        var details = request.Details != null
            ? JsonSerializer.Serialize(request.Details)
            : request.Description;

        var log = new AuditLog
        {
            AccountId = request.AccountId,
            Username = request.Username.Trim(),
            Action = request.Action.Trim(),
            ActionType = actionType,
            Module = module,
            TargetResource = request.TargetId,
            IpAddress = request.IpAddress,
            UserAgent = request.UserAgent,
            Status = status,
            Details = details,
            CreatedAt = DateTime.Now
        };

        _db.AuditLogs.Add(log);
        await _db.SaveChangesAsync();
        return ToDto(log);
    }

    public async Task SeedDemoDataAsync()
    {
        if (await _db.AuditLogs.AnyAsync()) return;

        var data = new[]
        {
            new AuditLog { Username = "admin", Action = "Đăng nhập hệ thống", Module = AuditModule.Auth, ActionType = AuditActionType.Login, Status = AuditStatus.Success, Details = "Đăng nhập thành công từ địa chỉ IP quản trị 192.168.1.10", IpAddress = "192.168.1.10", CreatedAt = new DateTime(2026, 9, 28, 8, 0, 15) },
            new AuditLog { Username = "admin", Action = "Cập nhật phân quyền vai trò", Module = AuditModule.Role, ActionType = AuditActionType.Update, Status = AuditStatus.Success, Details = "Chuyển vai trò tài khoản USR-005 sang MANAGER", TargetResource = "USR-005", IpAddress = "192.168.1.10", CreatedAt = new DateTime(2026, 9, 28, 8, 15, 20) },
            new AuditLog { Username = "manager", Action = "Cập nhật trạng thái khiếu nại", Module = AuditModule.Complaint, ActionType = AuditActionType.StatusChange, Status = AuditStatus.Success, Details = "Chuyển khiếu nại CMP-2026-002 sang trạng thái Đang xử lý", TargetResource = "CMP-2026-002", IpAddress = "192.168.1.25", CreatedAt = new DateTime(2026, 9, 27, 11, 30, 0) },
            new AuditLog { Username = "manager", Action = "Thay đổi thứ tự trạm dừng", Module = AuditModule.Stop, ActionType = AuditActionType.Update, Status = AuditStatus.Success, Details = "Điều chỉnh thứ tự trạm dừng STP-103 trên Tuyến 01", TargetResource = "STP-103", IpAddress = "192.168.1.25", CreatedAt = new DateTime(2026, 9, 27, 9, 40, 12) },
            new AuditLog { Username = "manager", Action = "Cập nhật biểu giá vé", Module = AuditModule.Fare, ActionType = AuditActionType.Update, Status = AuditStatus.Success, Details = "Cập nhật đơn giá vé Tuyến 04 là 15.000 VNĐ", TargetResource = "FAR-09", IpAddress = "192.168.1.25", CreatedAt = new DateTime(2026, 9, 26, 15, 20, 0) },
            new AuditLog { Username = "passenger", Action = "Gửi đánh giá chuyến đi", Module = AuditModule.Rating, ActionType = AuditActionType.FeedbackSubmit, Status = AuditStatus.Success, Details = "Gửi đánh giá 5 sao cho Tuyến 01", TargetResource = "RAT-2026-001", IpAddress = "14.161.45.12", CreatedAt = new DateTime(2026, 9, 27, 16, 30, 0) },
            new AuditLog { Username = "passenger", Action = "Gửi khiếu nại dịch vụ", Module = AuditModule.Complaint, ActionType = AuditActionType.FeedbackSubmit, Status = AuditStatus.Success, Details = "Nộp khiếu nại về sự cố xe trễ giờ", TargetResource = "CMP-2026-001", IpAddress = "14.161.45.12", CreatedAt = new DateTime(2026, 9, 26, 8, 30, 0) },
            new AuditLog { Username = "SYSTEM", Action = "Cảnh báo an ninh truy cập", Module = AuditModule.Auth, ActionType = AuditActionType.Login, Status = AuditStatus.Warning, Details = "Phát hiện đăng nhập sai mật khẩu 3 lần liên tiếp", IpAddress = "203.113.152.1", CreatedAt = new DateTime(2026, 9, 25, 23, 14, 2) }
        };

        var usernames = data.Select(x => x.Username).Where(x => x != "SYSTEM").Distinct().ToList();
        var accounts = await _db.Accounts.Where(x => usernames.Contains(x.Username)).ToDictionaryAsync(x => x.Username);

        foreach (var log in data)
        {
            if (accounts.TryGetValue(log.Username, out var account)) log.AccountId = account.Id;
            _db.AuditLogs.Add(log);
        }

        await _db.SaveChangesAsync();
    }

    private static AuditLogDto ToDto(AuditLog log)
    {
        Dictionary<string, object>? details = null;
        if (!string.IsNullOrWhiteSpace(log.Details))
        {
            try
            {
                details = JsonSerializer.Deserialize<Dictionary<string, object>>(log.Details!);
            }
            catch
            {
                details = new Dictionary<string, object> { ["description"] = log.Details! };
            }
        }

        return new AuditLogDto
        {
            Id = $"LOG-{log.CreatedAt:yyyy}-{log.Id:000}",
            User = log.Username,
            Action = log.Action,
            Module = log.Module.ToString().ToUpperInvariant(),
            Description = log.Details ?? string.Empty,
            DateTime = log.CreatedAt.ToString("yyyy-MM-dd HH:mm:ss"),
            Status = log.Status.ToString().ToUpperInvariant(),
            IpAddress = log.IpAddress,
            TargetId = log.TargetResource,
            Details = details
        };
    }
}
