namespace SmartBusTicketing.Api.DTOs;

public class AuditLogDto
{
    public string Id { get; set; } = null!;
    public string User { get; set; } = null!;
    public string Action { get; set; } = null!;
    public string Module { get; set; } = null!;
    public string Description { get; set; } = null!;
    public string DateTime { get; set; } = null!;
    public string Status { get; set; } = null!;
    public string? IpAddress { get; set; }
    public string? TargetId { get; set; }
    public Dictionary<string, object>? Details { get; set; }
}

public class CreateAuditLogRequest
{
    public long? AccountId { get; set; }
    public string Username { get; set; } = null!;
    public string Action { get; set; } = null!;
    public string ActionType { get; set; } = "VIEW";
    public string Module { get; set; } = "SYSTEM";
    public string? TargetId { get; set; }
    public string? IpAddress { get; set; }
    public string? UserAgent { get; set; }
    public string Status { get; set; } = "SUCCESS";
    public string? Description { get; set; }
    public Dictionary<string, object>? Details { get; set; }
}
