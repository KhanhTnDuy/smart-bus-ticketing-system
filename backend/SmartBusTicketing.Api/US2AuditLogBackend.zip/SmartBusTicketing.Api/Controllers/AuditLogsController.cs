using Microsoft.AspNetCore.Mvc;
using SmartBusTicketing.Api.DTOs;
using SmartBusTicketing.Api.Services;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/audit-logs")]
public class AuditLogsController : ControllerBase
{
    private readonly IAuditLogService _service;

    public AuditLogsController(IAuditLogService service) => _service = service;

    [HttpGet]
    public async Task<IActionResult> GetLogs(
        [FromQuery] string? search,
        [FromQuery] string? module,
        [FromQuery] string? status,
        [FromQuery] DateTime? date)
    {
        if (!IsAdmin()) return Forbid();
        return Ok(await _service.GetLogsAsync(search, module, status, date));
    }

    [HttpGet("{id:long}")]
    public async Task<IActionResult> GetById(long id)
    {
        if (!IsAdmin()) return Forbid();
        var result = await _service.GetByIdAsync(id);
        return result == null ? NotFound() : Ok(result);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateAuditLogRequest request)
    {
        if (!IsAuthenticated()) return Unauthorized();

        try
        {
            var result = await _service.CreateAsync(request);
            return StatusCode(StatusCodes.Status201Created, result);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPost("seed-demo")]
    public async Task<IActionResult> SeedDemo()
    {
        if (!IsAdmin()) return Forbid();
        await _service.SeedDemoDataAsync();
        return Ok(new { message = "Đã tạo dữ liệu audit log demo nếu bảng đang trống." });
    }

    private bool IsAuthenticated() =>
        Request.Headers.TryGetValue("X-User-Role", out var role) &&
        !string.IsNullOrWhiteSpace(role);

    private bool IsAdmin() =>
        Request.Headers.TryGetValue("X-User-Role", out var role) &&
        role.ToString().Equals("ADMIN", StringComparison.OrdinalIgnoreCase);
}
