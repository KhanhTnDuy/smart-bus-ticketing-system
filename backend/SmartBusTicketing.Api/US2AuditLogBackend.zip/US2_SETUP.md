# USER STORY 2 - NHẬT KÝ TRUY CẬP VÀ THAO TÁC

Phần này đã được ghép vào backend hiện tại của nhóm, không tạo project API mới.

## 1. Các file US2 đã thêm

SmartBusTicketing.Api/
- Controllers/AuditLogsController.cs
- DTOs/AuditLogDto.cs
- Services/AuditLogService.cs

Các file cũ được giữ lại và chỉ bổ sung:
- Models/Enums.cs -> AuditModule
- Models/Account.cs -> AuditLog.Module
- Data/AppDbContext.cs -> mapping Module + index
- Program.cs -> service + CORS

## 2. Database

Nếu database hiện tại đã có bảng `audit_logs`, chạy:

`database/US2_AuditLogs_Patch.sql`

Nếu bạn tạo database mới từ đầu, dùng `database/schema.sql` đã được cập nhật.

## 3. Chạy backend

Mở `SmartBusTicketing.slnx` bằng Visual Studio.

Set `SmartBusTicketing.Api` làm Startup Project.

Kiểm tra `appsettings.json`:

`Server=localhost;Port=3306;Database=smart_bus_ticketing;User=root;Password=MAT_KHAU_MYSQL;TreatTinyAsBoolean=true`

Run project. Lấy URL HTTPS mà Visual Studio hiển thị, ví dụ `https://localhost:7001`.

## 4. Test API

GET danh sách log, quyền Admin:

`GET https://localhost:7001/api/audit-logs`

Header:

`X-User-Role: ADMIN`

Lọc:

`GET /api/audit-logs?module=ROLE`
`GET /api/audit-logs?status=SUCCESS`
`GET /api/audit-logs?date=2026-09-28`
`GET /api/audit-logs?search=admin`

Tạo dữ liệu demo:

`POST /api/audit-logs/seed-demo`

Header:

`X-User-Role: ADMIN`

## 5. Liên kết với Frontend

Frontend hiện tại của nhóm đang dùng `AuditLogPage.tsx` và `DataContext.tsx` với mock/localStorage.

Không cần sửa giao diện `AuditLogPage.tsx`.

Copy `frontend-us2/auditLogApi.ts` vào `frontend/src/services/auditLogApi.ts` rồi làm theo `frontend-us2/README.md`.

API trả đúng các field mà màn hình đang dùng:

id, user, action, module, description, dateTime, status, ipAddress, targetId, details.

## 6. Luồng hoàn chỉnh

AuditLogPage.tsx
-> DataContext.tsx
-> auditLogApi.ts
-> GET /api/audit-logs
-> AuditLogsController
-> AuditLogService
-> AppDbContext
-> audit_logs
-> MySQL

## 7. Không copy đè

Không copy `AppDbContext.cs`, `Account.cs`, `Program.cs` từ một project US2 riêng vào project chính.
Chỉ dùng các file US2 đã được ghép trong ZIP này.
