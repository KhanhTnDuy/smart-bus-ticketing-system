USE smart_bus_ticketing;

ALTER TABLE audit_logs
    ADD COLUMN module VARCHAR(30) NOT NULL DEFAULT 'SYSTEM' AFTER action_type;

CREATE INDEX idx_audit_module ON audit_logs(module);
CREATE INDEX idx_audit_status ON audit_logs(status);

UPDATE audit_logs
SET module = CASE
    WHEN action_type IN ('LOGIN','LOGOUT') THEN 'AUTH'
    WHEN action_type = 'PAYMENT' THEN 'PAYMENT'
    WHEN action_type = 'TICKET_BUY' THEN 'TICKET'
    WHEN action_type = 'FEEDBACK_SUBMIT' THEN 'COMPLAINT'
    ELSE 'SYSTEM'
END
WHERE module = 'SYSTEM';
