# US2 - Audit Log integrated with SmartBusTicketing.Api

This version is integrated directly into the supplied `SmartBusTicketing.Api` project.

- Target framework: .NET 10
- Existing project/namespace: `SmartBusTicketing.Api`
- Database access: existing Entity Framework Core `AppDbContext`
- Existing `AuditLog` entity is extended with `Module`
- Admin-only endpoints: `GET /api/audit-logs` and `GET /api/audit-logs/{id}`
- Search: username, action, details, target resource
- Filters: module, status, date
- Server-side pagination: `page`, `pageSize`
- JWT validation is configured to accept the same `role`, `name`, issuer, audience and key settings used by the supplied US1 implementation.

## Database

Run `database/US2_AuditLogs.sql` once against `smart_bus_ticketing` if the existing database already contains `audit_logs`.

For a fresh database, `database/schema.sql` already contains the `module` column and index.

## Important

The supplied main backend currently did not contain the US1 authentication controllers/services. This US2 package only adds JWT validation and the Audit Log API; it does not copy the separate US1 project into the main backend.
