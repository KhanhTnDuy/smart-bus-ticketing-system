import { Role, User, UserStatus } from '../types';

const API_URL = `${import.meta.env.VITE_API_URL || 'http://localhost:5050'}/api`;

export interface AccountPayload {
  username?: string;
  fullName?: string;
  email?: string;
  phone?: string;
  role?: Role;
  status?: UserStatus;
  department?: string;
  avatarUrl?: string;
  password?: string;
}

function headers(role = 'ADMIN', username = 'admin', userId = 'USR-001') {
  return {
    'Content-Type': 'application/json',
    'X-User-Role': role,
    'X-User-Name': username,
    'X-User-Id': userId,
  };
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  actor?: { role?: string | null; username?: string; id?: string }
): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      ...headers(actor?.role || 'ADMIN', actor?.username || 'admin', actor?.id || 'USR-001'),
      ...(options.headers || {}),
    },
  });

  if (!response.ok) {
    let message = 'Không thể kết nối API.';
    try {
      const data = await response.json();
      message = data.message || message;
    } catch {
      // empty
    }
    throw new Error(message);
  }

  if (response.status === 204) return undefined as T;
  return response.json();
}

export const accountApi = {
  getAll: (
    filters?: { search?: string; role?: string; status?: string },
    actor?: { role?: string | null; username?: string; id?: string }
  ) => {
    const params = new URLSearchParams();
    if (filters?.search) params.set('search', filters.search);
    if (filters?.role && filters.role !== 'ALL') params.set('role', filters.role);
    if (filters?.status && filters.status !== 'ALL') params.set('status', filters.status);

    const query = params.toString();
    return request<User[]>(`/accounts${query ? `?${query}` : ''}`, {}, actor);
  },

  getById: (id: string, actor?: { role?: string | null; username?: string; id?: string }) =>
    request<User>(`/accounts/${id}`, {}, actor),

  create: (data: AccountPayload, actor?: { role?: string | null; username?: string; id?: string }) =>
    request<User>(
      '/accounts',
      { method: 'POST', body: JSON.stringify(data) },
      actor
    ),

  update: (
    id: string,
    data: AccountPayload,
    actor?: { role?: string | null; username?: string; id?: string }
  ) =>
    request<User>(
      `/accounts/${id}`,
      { method: 'PUT', body: JSON.stringify(data) },
      actor
    ),

  assignRole: (
    id: string,
    role: Role,
    actor?: { role?: string | null; username?: string; id?: string }
  ) =>
    request<User>(
      `/accounts/${id}/role`,
      { method: 'PATCH', body: JSON.stringify({ role }) },
      actor
    ),

  remove: (id: string, actor?: { role?: string | null; username?: string; id?: string }) =>
    request<void>(`/accounts/${id}`, { method: 'DELETE' }, actor),
};
