# User Story 1 - Account Management API

Branch đề xuất: `feature/us1-account-management`

## Chức năng

- Xem danh sách tài khoản
- Xem chi tiết
- Thêm tài khoản
- Sửa tài khoản
- Xóa tài khoản
- Phân quyền ADMIN / MANAGER / DRIVER / PASSENGER
- Lọc theo search, role, status
- Ghi audit log cho CREATE / UPDATE / DELETE / ROLE
- CORS cho Vite React
- MySQL 8
- ASP.NET Core 8 Web API

## 1. Database

Mở MySQL và chạy:

```sql
source database/schema.sql;
```

`database/schema.sql` là schema nhóm đã được bổ sung các cột `status`, `department`, `avatar_url` cho User Story 1.

Nếu database hiện tại đã chạy schema cũ, có thể dùng:

```sql
source database/US1_AccountManagement.sql;
```

Backend cũng tự kiểm tra các cột này khi khởi động.

## 2. Backend

Sửa mật khẩu MySQL trong:

`backend/SmartBusTicketing.Api/appsettings.json`

Sau đó:

```bash
cd backend/SmartBusTicketing.Api
dotnet restore
dotnet run
```

API:

`http://localhost:5050`

Swagger:

`http://localhost:5050/swagger`

Tài khoản seed khi database chưa có account:

- admin / 123456
- manager / 123456
- driver / 123456
- passenger / 123456

## 3. Frontend

Copy 3 file:

- `frontend/src/services/accountApi.ts`
- `frontend/src/context/DataContext.tsx`
- `frontend/src/pages/admin/AccountManagementPage.tsx`
- `frontend/src/pages/admin/RoleAssignmentPage.tsx`

Thêm:

```env
VITE_API_URL=http://localhost:5050
```

Sau đó:

```bash
npm install
npm run dev
```

## API

```text
GET    /api/accounts
GET    /api/accounts/{id}
POST   /api/accounts
PUT    /api/accounts/{id}
PATCH  /api/accounts/{id}/role
DELETE /api/accounts/{id}
```

Frontend gửi các header demo:

```text
X-User-Role
X-User-Name
X-User-Id
```

API quản lý tài khoản chỉ cho `ADMIN`. Đây là cơ chế demo để nối User Story 1; khi làm đăng nhập thật nên thay bằng JWT + `[Authorize]`.

## Git branch

```bash
git checkout -b feature/us1-account-management
git add .
git commit -m "feat: implement US1 account management API"
git push -u origin feature/us1-account-management
```
