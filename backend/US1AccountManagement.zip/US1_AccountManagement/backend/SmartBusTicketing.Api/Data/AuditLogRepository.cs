using MySqlConnector;

namespace SmartBusTicketing.Api.Data;

public sealed class AuditLogRepository : Db
{
    public AuditLogRepository(IConfiguration configuration) : base(configuration) { }

    public async Task AddAsync(
        long? accountId,
        string username,
        string action,
        string actionType,
        string? targetResource,
        string status,
        string? details,
        string? ipAddress)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();

        const string sql = """
            INSERT INTO audit_logs
                (account_id, username, action, action_type, target_resource, ip_address, status, details)
            VALUES
                (@accountId, @username, @action, @actionType, @targetResource, @ipAddress, @status, @details);
            """;

        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@accountId", (object?)accountId ?? DBNull.Value);
        command.Parameters.AddWithValue("@username", username);
        command.Parameters.AddWithValue("@action", action);
        command.Parameters.AddWithValue("@actionType", actionType);
        command.Parameters.AddWithValue("@targetResource", (object?)targetResource ?? DBNull.Value);
        command.Parameters.AddWithValue("@ipAddress", (object?)ipAddress ?? DBNull.Value);
        command.Parameters.AddWithValue("@status", status);
        command.Parameters.AddWithValue("@details", (object?)details ?? DBNull.Value);

        await command.ExecuteNonQueryAsync();
    }
}
