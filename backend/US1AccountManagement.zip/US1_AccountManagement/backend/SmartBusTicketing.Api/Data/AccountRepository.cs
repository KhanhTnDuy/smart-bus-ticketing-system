using BCrypt.Net;
using MySqlConnector;
using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.Data;

public sealed class AccountRepository : Db
{
    private static readonly string[] AllowedRoles = ["ADMIN", "MANAGER", "DRIVER", "PASSENGER"];
    private static readonly string[] AllowedStatuses = ["ACTIVE", "INACTIVE", "LOCKED"];

    public AccountRepository(IConfiguration configuration) : base(configuration) { }

    public static bool IsRoleValid(string role) => AllowedRoles.Contains(role);
    public static bool IsStatusValid(string status) => AllowedStatuses.Contains(status);

    public async Task InitializeAsync()
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();

        const string accountsSql = """
            CREATE TABLE IF NOT EXISTS accounts (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                email VARCHAR(100) UNIQUE,
                phone VARCHAR(20) UNIQUE,
                role ENUM('ADMIN','MANAGER','DRIVER','CONDUCTOR','PASSENGER') NOT NULL DEFAULT 'PASSENGER',
                active BOOLEAN NOT NULL DEFAULT TRUE,
                status ENUM('ACTIVE','INACTIVE','LOCKED') NOT NULL DEFAULT 'ACTIVE',
                department VARCHAR(150) NULL,
                avatar_url VARCHAR(500) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            );
            """;

        const string auditSql = """
            CREATE TABLE IF NOT EXISTS audit_logs (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                account_id BIGINT NULL,
                username VARCHAR(100) NOT NULL,
                action VARCHAR(300) NOT NULL,
                action_type ENUM('LOGIN','LOGOUT','CREATE','UPDATE','DELETE','VIEW','EXPORT','PAYMENT','TICKET_BUY','FEEDBACK_SUBMIT','STATUS_CHANGE') NOT NULL,
                target_resource VARCHAR(200) NULL,
                ip_address VARCHAR(45) NULL,
                user_agent VARCHAR(500) NULL,
                status ENUM('SUCCESS','FAILURE','WARNING') NOT NULL DEFAULT 'SUCCESS',
                details TEXT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL
            );
            """;

        await using (var command = new MySqlCommand(accountsSql, connection))
            await command.ExecuteNonQueryAsync();

        await using (var command = new MySqlCommand(auditSql, connection))
            await command.ExecuteNonQueryAsync();

        await EnsureColumnAsync(connection, "accounts", "status",
            "ALTER TABLE accounts ADD COLUMN status ENUM('ACTIVE','INACTIVE','LOCKED') NOT NULL DEFAULT 'ACTIVE'");
        await EnsureColumnAsync(connection, "accounts", "department",
            "ALTER TABLE accounts ADD COLUMN department VARCHAR(150) NULL");
        await EnsureColumnAsync(connection, "accounts", "avatar_url",
            "ALTER TABLE accounts ADD COLUMN avatar_url VARCHAR(500) NULL");

        if (await CountAsync(connection) == 0)
            await SeedAsync(connection);
    }

    public async Task<List<Account>> GetAllAsync(string? search, string? role, string? status)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();

        var sql = """
            SELECT id, username, full_name, email, phone, role, status, created_at, avatar_url, department
            FROM accounts
            WHERE role <> 'CONDUCTOR'
            """;

        if (!string.IsNullOrWhiteSpace(search))
            sql += " AND (username LIKE @search OR full_name LIKE @search OR email LIKE @search OR phone LIKE @search)";
        if (!string.IsNullOrWhiteSpace(role) && role != "ALL")
            sql += " AND role = @role";
        if (!string.IsNullOrWhiteSpace(status) && status != "ALL")
            sql += " AND status = @status";

        sql += " ORDER BY id DESC;";

        await using var command = new MySqlCommand(sql, connection);
        if (!string.IsNullOrWhiteSpace(search))
            command.Parameters.AddWithValue("@search", $"%{search.Trim()}%");
        if (!string.IsNullOrWhiteSpace(role) && role != "ALL")
            command.Parameters.AddWithValue("@role", role);
        if (!string.IsNullOrWhiteSpace(status) && status != "ALL")
            command.Parameters.AddWithValue("@status", status);

        var result = new List<Account>();
        await using var reader = await command.ExecuteReaderAsync();

        while (await reader.ReadAsync())
            result.Add(Map(reader));

        return result;
    }

    public async Task<Account?> GetByIdAsync(long id)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();

        const string sql = """
            SELECT id, username, full_name, email, phone, role, status, created_at, avatar_url, department
            FROM accounts
            WHERE id = @id;
            """;

        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", id);

        await using var reader = await command.ExecuteReaderAsync();
        return await reader.ReadAsync() ? Map(reader) : null;
    }

    public async Task<Account> CreateAsync(CreateAccountRequest request)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();

        const string sql = """
            INSERT INTO accounts
                (username, password_hash, full_name, email, phone, role, active, status, department, avatar_url)
            VALUES
                (@username, @passwordHash, @fullName, @email, @phone, @role, @active, @status, @department, @avatarUrl);
            """;

        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@username", request.Username.Trim());
        command.Parameters.AddWithValue("@passwordHash",
            BCrypt.HashPassword(string.IsNullOrWhiteSpace(request.Password) ? "123456" : request.Password));
        command.Parameters.AddWithValue("@fullName", request.FullName.Trim());
        command.Parameters.AddWithValue("@email", request.Email.Trim().ToLowerInvariant());
        command.Parameters.AddWithValue("@phone", request.Phone.Trim());
        command.Parameters.AddWithValue("@role", request.Role);
        command.Parameters.AddWithValue("@active", request.Status == "ACTIVE");
        command.Parameters.AddWithValue("@status", request.Status);
        command.Parameters.AddWithValue("@department", (object?)request.Department ?? DBNull.Value);
        command.Parameters.AddWithValue("@avatarUrl", (object?)request.AvatarUrl ?? DBNull.Value);

        await command.ExecuteNonQueryAsync();

        await using var idCommand = new MySqlCommand("SELECT LAST_INSERT_ID();", connection);
        var id = Convert.ToInt64(await idCommand.ExecuteScalarAsync());

        return (await GetByIdAsync(id))!;
    }

    public async Task<Account?> UpdateAsync(long id, UpdateAccountRequest request)
    {
        var fields = new List<string>();
        var parameters = new List<MySqlParameter>();

        if (request.FullName is not null)
        {
            fields.Add("full_name = @fullName");
            parameters.Add(new MySqlParameter("@fullName", request.FullName.Trim()));
        }
        if (request.Email is not null)
        {
            fields.Add("email = @email");
            parameters.Add(new MySqlParameter("@email", request.Email.Trim().ToLowerInvariant()));
        }
        if (request.Phone is not null)
        {
            fields.Add("phone = @phone");
            parameters.Add(new MySqlParameter("@phone", request.Phone.Trim()));
        }
        if (request.Role is not null)
        {
            fields.Add("role = @role");
            parameters.Add(new MySqlParameter("@role", request.Role));
        }
        if (request.Status is not null)
        {
            fields.Add("status = @status");
            fields.Add("active = (@status = 'ACTIVE')");
            parameters.Add(new MySqlParameter("@status", request.Status));
        }
        if (request.Department is not null)
        {
            fields.Add("department = @department");
            parameters.Add(new MySqlParameter("@department", request.Department.Trim()));
        }
        if (request.AvatarUrl is not null)
        {
            fields.Add("avatar_url = @avatarUrl");
            parameters.Add(new MySqlParameter("@avatarUrl", request.AvatarUrl.Trim()));
        }

        if (fields.Count == 0)
            return await GetByIdAsync(id);

        await using var connection = CreateConnection();
        await connection.OpenAsync();

        var sql = $"UPDATE accounts SET {string.Join(", ", fields)} WHERE id = @id;";
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", id);
        foreach (var parameter in parameters)
            command.Parameters.Add(parameter);

        await command.ExecuteNonQueryAsync();
        return await GetByIdAsync(id);
    }

    public async Task<bool> DeleteAsync(long id)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();

        const string sql = "DELETE FROM accounts WHERE id = @id;";
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", id);

        return await command.ExecuteNonQueryAsync() > 0;
    }

    public async Task<(bool Success, string? OldRole, string? Username)> AssignRoleAsync(long id, string role)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();

        const string findSql = "SELECT role, username FROM accounts WHERE id = @id;";
        await using var find = new MySqlCommand(findSql, connection);
        find.Parameters.AddWithValue("@id", id);

        string? oldRole = null;
        string? username = null;

        await using (var reader = await find.ExecuteReaderAsync())
        {
            if (!await reader.ReadAsync())
                return (false, null, null);

            oldRole = reader.GetString("role");
            username = reader.GetString("username");
        }

        const string updateSql = "UPDATE accounts SET role = @role WHERE id = @id;";
        await using var update = new MySqlCommand(updateSql, connection);
        update.Parameters.AddWithValue("@role", role);
        update.Parameters.AddWithValue("@id", id);
        await update.ExecuteNonQueryAsync();

        return (true, oldRole, username);
    }

    public async Task<long?> FindIdByUsernameAsync(string username)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();

        const string sql = "SELECT id FROM accounts WHERE username = @username LIMIT 1;";
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@username", username);

        var result = await command.ExecuteScalarAsync();
        return result is null ? null : Convert.ToInt64(result);
    }

    private static async Task<int> CountAsync(MySqlConnection connection)
    {
        await using var command = new MySqlCommand("SELECT COUNT(*) FROM accounts;", connection);
        return Convert.ToInt32(await command.ExecuteScalarAsync());
    }

    private static async Task EnsureColumnAsync(MySqlConnection connection, string table, string column, string sql)
    {
        const string checkSql = """
            SELECT COUNT(*)
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @table AND COLUMN_NAME = @column;
            """;

        await using var check = new MySqlCommand(checkSql, connection);
        check.Parameters.AddWithValue("@table", table);
        check.Parameters.AddWithValue("@column", column);

        if (Convert.ToInt32(await check.ExecuteScalarAsync()) == 0)
        {
            await using var alter = new MySqlCommand(sql, connection);
            await alter.ExecuteNonQueryAsync();
        }
    }

    private static async Task SeedAsync(MySqlConnection connection)
    {
        var users = new[]
        {
            ("admin", "Nguyễn Văn An", "admin@bus.com", "0901234567", "ADMIN", "Ban Giám Đốc / Trung Tâm CNTT"),
            ("manager", "Trần Minh Đức", "manager@bus.com", "0912345678", "MANAGER", "Phòng Điều Hành & Kế Hoạch Tuyến"),
            ("driver", "Lê Thị Mai", "driver@bus.com", "0987654321", "DRIVER", "Đội Xe Tuyến 01 - Đội Vận Tải 1"),
            ("passenger", "Phạm Quốc Huy", "passenger@bus.com", "0934567890", "PASSENGER", "Khách hàng cá nhân"),
            ("tuyendieuphoi", "Hoàng Văn Thắng", "thang.hoang@bus.com", "0945671234", "MANAGER", "Phòng Giám Sát & Điều Độ Xe"),
            ("taixe_bui", "Bùi Tuấn Anh", "tuananh.bui@bus.com", "0967890123", "DRIVER", "Đội Xe Tuyến 03 - Đội Vận Tải 2"),
            ("hiep_khach", "Đỗ Thị Thu Hà", "thuha.do@bus.com", "0978901234", "PASSENGER", "Khách hàng cá nhân")
        };

        const string sql = """
            INSERT INTO accounts
                (username, password_hash, full_name, email, phone, role, active, status, department)
            VALUES
                (@username, @passwordHash, @fullName, @email, @phone, @role, TRUE, 'ACTIVE', @department);
            """;

        foreach (var user in users)
        {
            await using var command = new MySqlCommand(sql, connection);
            command.Parameters.AddWithValue("@username", user.Item1);
            command.Parameters.AddWithValue("@passwordHash", BCrypt.HashPassword("123456"));
            command.Parameters.AddWithValue("@fullName", user.Item2);
            command.Parameters.AddWithValue("@email", user.Item3);
            command.Parameters.AddWithValue("@phone", user.Item4);
            command.Parameters.AddWithValue("@role", user.Item5);
            command.Parameters.AddWithValue("@department", user.Item6);
            await command.ExecuteNonQueryAsync();
        }
    }

    private static Account Map(MySqlDataReader reader)
    {
        var id = reader.GetInt64("id");

        return new Account
        {
            Id = $"USR-{id:D3}",
            Username = reader.GetString("username"),
            FullName = reader.GetString("full_name"),
            Email = reader.IsDBNull(reader.GetOrdinal("email")) ? "" : reader.GetString("email"),
            Phone = reader.IsDBNull(reader.GetOrdinal("phone")) ? "" : reader.GetString("phone"),
            Role = reader.GetString("role"),
            Status = reader.GetString("status"),
            CreatedAt = reader.GetDateTime("created_at"),
            AvatarUrl = reader.IsDBNull(reader.GetOrdinal("avatar_url")) ? null : reader.GetString("avatar_url"),
            Department = reader.IsDBNull(reader.GetOrdinal("department")) ? null : reader.GetString("department")
        };
    }
}
