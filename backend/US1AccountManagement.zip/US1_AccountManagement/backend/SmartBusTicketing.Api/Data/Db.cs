using MySqlConnector;

namespace SmartBusTicketing.Api.Data;

public abstract class Db
{
    protected Db(IConfiguration configuration)
    {
        ConnectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("DefaultConnection is missing.");
    }

    protected string ConnectionString { get; }

    protected MySqlConnection CreateConnection() => new(ConnectionString);
}
