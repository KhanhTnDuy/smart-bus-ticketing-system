namespace SmartBusTicketing.Api.Models;

public sealed class CreateAccountRequest
{
    public string Username { get; set; } = "";
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Role { get; set; } = "PASSENGER";
    public string Status { get; set; } = "ACTIVE";
    public string? Department { get; set; }
    public string? AvatarUrl { get; set; }
    public string? Password { get; set; }
}

public sealed class UpdateAccountRequest
{
    public string? FullName { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string? Role { get; set; }
    public string? Status { get; set; }
    public string? Department { get; set; }
    public string? AvatarUrl { get; set; }
}

public sealed class AssignRoleRequest
{
    public string Role { get; set; } = "PASSENGER";
}
