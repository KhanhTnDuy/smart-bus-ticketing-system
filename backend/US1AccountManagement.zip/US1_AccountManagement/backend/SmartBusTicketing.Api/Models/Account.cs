namespace SmartBusTicketing.Api.Models;

public sealed class Account
{
    public string Id { get; init; } = "";
    public string Username { get; init; } = "";
    public string FullName { get; init; } = "";
    public string Email { get; init; } = "";
    public string Phone { get; init; } = "";
    public string Role { get; init; } = "PASSENGER";
    public string Status { get; init; } = "ACTIVE";
    public DateTime CreatedAt { get; init; }
    public string? AvatarUrl { get; init; }
    public string? Department { get; init; }
}
