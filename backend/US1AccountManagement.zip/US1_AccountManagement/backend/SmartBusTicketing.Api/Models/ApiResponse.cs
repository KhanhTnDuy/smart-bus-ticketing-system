namespace SmartBusTicketing.Api.Models;

public sealed record ApiError(string Message);
