using Microsoft.AspNetCore.Mvc;
using SmartBusTicketing.Api.Models;
using SmartBusTicketing.Api.Services;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/accounts")]
public sealed class AccountsController : ControllerBase
{
    private readonly AccountService _service;

    public AccountsController(AccountService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] string? search,
        [FromQuery] string? role,
        [FromQuery] string? status)
    {
        if (!IsAdmin())
            return Forbid();

        var data = await _service.GetAllAsync(search, role, status);
        return Ok(data);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(string id)
    {
        if (!IsAdmin())
            return Forbid();

        if (!TryParseId(id, out var numericId))
            return BadRequest(new ApiError("ID tài khoản không hợp lệ."));

        var data = await _service.GetByIdAsync(numericId);
        return data is null ? NotFound(new ApiError("Không tìm thấy tài khoản.")) : Ok(data);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateAccountRequest request)
    {
        if (!IsAdmin())
            return Forbid();

        var result = await _service.CreateAsync(
            request,
            ActorUsername(),
            HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown");

        if (!result.Success)
            return BadRequest(new ApiError(result.Message));

        return CreatedAtAction(nameof(GetById), new { id = result.Data!.Id }, result.Data);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(string id, [FromBody] UpdateAccountRequest request)
    {
        if (!IsAdmin())
            return Forbid();

        if (!TryParseId(id, out var numericId))
            return BadRequest(new ApiError("ID tài khoản không hợp lệ."));

        var result = await _service.UpdateAsync(
            numericId,
            request,
            ActorUsername(),
            HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown");

        if (!result.Success)
            return result.Message == "Không tìm thấy tài khoản."
                ? NotFound(new ApiError(result.Message))
                : BadRequest(new ApiError(result.Message));

        return Ok(result.Data);
    }

    [HttpPatch("{id}/role")]
    public async Task<IActionResult> AssignRole(string id, [FromBody] AssignRoleRequest request)
    {
        if (!IsAdmin())
            return Forbid();

        if (!TryParseId(id, out var numericId))
            return BadRequest(new ApiError("ID tài khoản không hợp lệ."));

        var result = await _service.AssignRoleAsync(
            numericId,
            request.Role.Trim().ToUpperInvariant(),
            ActorUsername(),
            HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown");

        if (!result.Success)
            return result.Message == "Không tìm thấy tài khoản."
                ? NotFound(new ApiError(result.Message))
                : BadRequest(new ApiError(result.Message));

        return Ok(result.Data);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        if (!IsAdmin())
            return Forbid();

        if (!TryParseId(id, out var numericId))
            return BadRequest(new ApiError("ID tài khoản không hợp lệ."));

        var result = await _service.DeleteAsync(
            numericId,
            ActorUsername(),
            Request.Headers["X-User-Id"].FirstOrDefault() ?? "",
            HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown");

        if (!result.Success)
        {
            if (result.Message == "Không tìm thấy tài khoản.")
                return NotFound(new ApiError(result.Message));

            if (result.Message.Contains("đang được dữ liệu khác tham chiếu"))
                return Conflict(new ApiError(result.Message));

            return BadRequest(new ApiError(result.Message));
        }

        return NoContent();
    }

    private bool IsAdmin()
        => string.Equals(
            Request.Headers["X-User-Role"].FirstOrDefault(),
            "ADMIN",
            StringComparison.OrdinalIgnoreCase);

    private string ActorUsername()
        => Request.Headers["X-User-Name"].FirstOrDefault() ?? "admin";

    private static bool TryParseId(string value, out long id)
    {
        if (value.StartsWith("USR-", StringComparison.OrdinalIgnoreCase))
            return long.TryParse(value[4..], out id);

        return long.TryParse(value, out id);
    }
}
