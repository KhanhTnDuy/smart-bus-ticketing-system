using MySqlConnector;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.Services;

public sealed class AccountService
{
    private readonly AccountRepository _repository;
    private readonly AuditLogRepository _audit;

    public AccountService(AccountRepository repository, AuditLogRepository audit)
    {
        _repository = repository;
        _audit = audit;
    }

    public Task<List<Account>> GetAllAsync(string? search, string? role, string? status)
        => _repository.GetAllAsync(search, role, status);

    public Task<Account?> GetByIdAsync(long id)
        => _repository.GetByIdAsync(id);

    public async Task<(bool Success, string Message, Account? Data)> CreateAsync(
        CreateAccountRequest request, string actorUsername, string ip)
    {
        Normalize(request);

        if (!AccountRepository.IsRoleValid(request.Role))
            return (false, "Vai trò không hợp lệ.", null);

        if (!AccountRepository.IsStatusValid(request.Status))
            return (false, "Trạng thái không hợp lệ.", null);

        if (request.Username.Length < 3)
            return (false, "Tên đăng nhập phải có ít nhất 3 ký tự.", null);

        if (string.IsNullOrWhiteSpace(request.FullName))
            return (false, "Họ và tên không được để trống.", null);

        if (!IsEmail(request.Email))
            return (false, "Email không hợp lệ.", null);

        if (!IsPhone(request.Phone))
            return (false, "Số điện thoại phải có 9 đến 11 chữ số.", null);

        try
        {
            var account = await _repository.CreateAsync(request);
            await WriteAudit(actorUsername, "Thêm tài khoản người dùng", "CREATE", account.Id, ip,
                $"Tạo {account.Username} với vai trò {account.Role}");
            return (true, "Tạo tài khoản thành công.", account);
        }
        catch (MySqlException ex) when (ex.Number == 1062)
        {
            return (false, "Username, email hoặc số điện thoại đã tồn tại.", null);
        }
    }

    public async Task<(bool Success, string Message, Account? Data)> UpdateAsync(
        long id, UpdateAccountRequest request, string actorUsername, string ip)
    {
        if (request.Role is not null && !AccountRepository.IsRoleValid(request.Role))
            return (false, "Vai trò không hợp lệ.", null);

        if (request.Status is not null && !AccountRepository.IsStatusValid(request.Status))
            return (false, "Trạng thái không hợp lệ.", null);

        if (request.Email is not null && !IsEmail(request.Email))
            return (false, "Email không hợp lệ.", null);

        if (request.Phone is not null && !IsPhone(request.Phone))
            return (false, "Số điện thoại phải có 9 đến 11 chữ số.", null);

        if (request.FullName is not null && string.IsNullOrWhiteSpace(request.FullName))
            return (false, "Họ và tên không được để trống.", null);

        try
        {
            var account = await _repository.UpdateAsync(id, request);
            if (account is null)
                return (false, "Không tìm thấy tài khoản.", null);

            await WriteAudit(actorUsername, "Cập nhật thông tin tài khoản", "UPDATE", account.Id, ip,
                $"Cập nhật {account.Username}");
            return (true, "Cập nhật thành công.", account);
        }
        catch (MySqlException ex) when (ex.Number == 1062)
        {
            return (false, "Email hoặc số điện thoại đã tồn tại.", null);
        }
    }

    public async Task<(bool Success, string Message)> DeleteAsync(
        long id, string actorUsername, string actorId, string ip)
    {
        if (actorId == $"USR-{id:D3}")
            return (false, "Bạn không thể xóa tài khoản đang đăng nhập.");

        var account = await _repository.GetByIdAsync(id);
        if (account is null)
            return (false, "Không tìm thấy tài khoản.");

        try
        {
            if (!await _repository.DeleteAsync(id))
                return (false, "Xóa tài khoản thất bại.");

            await WriteAudit(null, actorUsername, "Xóa tài khoản người dùng", "DELETE", account.Id, ip,
                $"Xóa {account.Username} - {account.FullName}");
            return (true, "Xóa tài khoản thành công.");
        }
        catch (MySqlException ex) when (ex.Number == 1451)
        {
            return (false, "Không thể xóa vì tài khoản đang được dữ liệu khác tham chiếu.");
        }
    }

    public async Task<(bool Success, string Message, Account? Data)> AssignRoleAsync(
        long id, string role, string actorUsername, string ip)
    {
        if (!AccountRepository.IsRoleValid(role))
            return (false, "Vai trò không hợp lệ.", null);

        var result = await _repository.AssignRoleAsync(id, role);
        if (!result.Success)
            return (false, "Không tìm thấy tài khoản.", null);

        var account = await _repository.GetByIdAsync(id);
        await WriteAudit(actorUsername, "Phân quyền vai trò", "STATUS_CHANGE", account?.Id, ip,
            $"{result.Username}: {result.OldRole} -> {role}");

        return (true, "Phân quyền thành công.", account);
    }

    private async Task WriteAudit(
        string actorUsername,
        string action,
        string actionType,
        string? targetId,
        string ip,
        string details)
    {
        var actorId = await _repository.FindIdByUsernameAsync(actorUsername);

        await _audit.AddAsync(
            actorId,
            actorUsername,
            action,
            actionType,
            targetId,
            "SUCCESS",
            details,
            ip);
    }

    private async Task WriteAudit(
        long? actorId,
        string actorUsername,
        string action,
        string actionType,
        string? targetId,
        string ip,
        string details)
    {
        await _audit.AddAsync(
            actorId,
            actorUsername,
            action,
            actionType,
            targetId,
            "SUCCESS",
            details,
            ip);
    }

    private static void Normalize(CreateAccountRequest request)
    {
        request.Username = request.Username.Trim();
        request.FullName = request.FullName.Trim();
        request.Email = request.Email.Trim().ToLowerInvariant();
        request.Phone = request.Phone.Trim();
        request.Role = request.Role.Trim().ToUpperInvariant();
        request.Status = request.Status.Trim().ToUpperInvariant();
    }

    private static bool IsEmail(string email)
        => System.Text.RegularExpressions.Regex.IsMatch(
            email, @"^[^\s@]+@[^\s@]+\.[^\s@]+$");

    private static bool IsPhone(string phone)
        => System.Text.RegularExpressions.Regex.IsMatch(phone, @"^\d{9,11}$");
}
