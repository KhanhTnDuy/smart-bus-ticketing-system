USE smart_bus_ticketing;

ALTER TABLE audit_logs
    ADD COLUMN module VARCHAR(30) NOT NULL DEFAULT 'System' AFTER action_type;

CREATE INDEX idx_audit_module_status_time
    ON audit_logs (module, status, created_at);

UPDATE audit_logs
SET module = CASE
    WHEN action_type IN ('LOGIN', 'LOGOUT') THEN 'Auth'
    WHEN action_type IN ('CREATE', 'UPDATE', 'DELETE', 'VIEW', 'EXPORT') THEN 'Account'
    WHEN action_type = 'PAYMENT' THEN 'Payment'
    WHEN action_type = 'TICKET_BUY' THEN 'Ticket'
    WHEN action_type = 'FEEDBACK_SUBMIT' THEN 'Complaint'
    WHEN action_type = 'STATUS_CHANGE' THEN 'System'
    ELSE 'System'
END;
