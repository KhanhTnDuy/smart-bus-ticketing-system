using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.Models;
using SmartBusTicketing.US3.Models;

namespace SmartBusTicketing.US3.Controllers;

[ApiController]
[Route("api/routes")]
public sealed class RoutesController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> List(CancellationToken ct)
    {
        var routes = await db.BusRoutes.AsNoTracking().OrderBy(x => x.Code)
            .Select(x => new { x.Id, x.Code, x.Name, x.StartPoint, x.EndPoint, x.DistanceKm, x.Active })
            .ToListAsync(ct);
        return Ok(routes);
    }

    [HttpGet("{id:long}")]
    [AllowAnonymous]
    public async Task<IActionResult> Get(long id, CancellationToken ct)
    {
        var route = await db.BusRoutes.AsNoTracking()
            .Include(x => x.RouteStops).ThenInclude(x => x.Stop)
            .Include(x => x.Fares)
            .Where(x => x.Id == id)
            .Select(x => new
            {
                x.Id, x.Code, x.Name, x.StartPoint, x.EndPoint, x.DistanceKm, x.Active,
                Stops = x.RouteStops.OrderBy(s => s.StopOrder).Select(s => new { s.StopId, s.StopOrder, s.MinutesFromStart, s.Stop.Name, s.Stop.Latitude, s.Stop.Longitude }),
                Fares = x.Fares.OrderByDescending(f => f.EffectiveFrom).Select(f => new { f.Id, f.TicketType, f.PassengerTypeId, f.Price, f.EffectiveFrom })
            }).SingleOrDefaultAsync(ct);
        return route is null ? NotFound(new { message = "Không tìm thấy tuyến đường." }) : Ok(route);
    }

    [HttpPost]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> Create(CreateRouteRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Code) || string.IsNullOrWhiteSpace(request.Name)) return BadRequest(new { message = "Code và Name không được để trống." });
        if (request.DistanceKm < 0) return BadRequest(new { message = "DistanceKm không hợp lệ." });
        var code = request.Code.Trim();
        if (await db.BusRoutes.AnyAsync(x => x.Code == code, ct)) return Conflict(new { message = "Mã tuyến đã tồn tại." });
        var route = new BusRoute { Code = code, Name = request.Name.Trim(), StartPoint = request.StartPoint.Trim(), EndPoint = request.EndPoint.Trim(), DistanceKm = request.DistanceKm, Active = request.Active };
        db.BusRoutes.Add(route);
        await db.SaveChangesAsync(ct);
        await AddAudit("Create", AuditActionType.Create, AuditModule.Route, route.Id.ToString(), $"Tạo tuyến {route.Code}", ct);
        return CreatedAtAction(nameof(Get), new { id = route.Id }, route);
    }

    [HttpPut("{id:long}")]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> Update(long id, UpdateRouteRequest request, CancellationToken ct)
    {
        var route = await db.BusRoutes.FindAsync([id], ct);
        if (route is null) return NotFound(new { message = "Không tìm thấy tuyến đường." });
        var code = request.Code.Trim();
        if (await db.BusRoutes.AnyAsync(x => x.Id != id && x.Code == code, ct)) return Conflict(new { message = "Mã tuyến đã tồn tại." });
        route.Code = code; route.Name = request.Name.Trim(); route.StartPoint = request.StartPoint.Trim(); route.EndPoint = request.EndPoint.Trim(); route.DistanceKm = request.DistanceKm; route.Active = request.Active;
        await db.SaveChangesAsync(ct);
        await AddAudit("Update", AuditActionType.Update, AuditModule.Route, id.ToString(), $"Cập nhật tuyến {route.Code}", ct);
        return Ok(route);
    }

    [HttpDelete("{id:long}")]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> Delete(long id, CancellationToken ct)
    {
        var route = await db.BusRoutes.FindAsync([id], ct);
        if (route is null) return NotFound(new { message = "Không tìm thấy tuyến đường." });
        route.Active = false;
        await db.SaveChangesAsync(ct);
        await AddAudit("Delete", AuditActionType.Delete, AuditModule.Route, id.ToString(), $"Ngừng hoạt động tuyến {route.Code}", ct);
        return Ok(new { message = "Tuyến đã chuyển sang không hoạt động." });
    }

    [HttpPut("{id:long}/stops")]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> UpdateStops(long id, UpdateRouteStopsRequest request, CancellationToken ct)
    {
        var route = await db.BusRoutes.FindAsync([id], ct);
        if (route is null) return NotFound(new { message = "Không tìm thấy tuyến đường." });
        if (request.Stops is null || request.Stops.Count == 0) return BadRequest(new { message = "Danh sách trạm không được rỗng." });
        if (request.Stops.GroupBy(x => x.StopId).Any(g => g.Count() > 1) || request.Stops.GroupBy(x => x.StopOrder).Any(g => g.Count() > 1)) return BadRequest(new { message = "StopId và StopOrder không được trùng." });
        var ids = request.Stops.Select(x => x.StopId).Distinct().ToList();
        var existing = await db.Stops.Where(x => ids.Contains(x.Id)).Select(x => x.Id).ToListAsync(ct);
        if (existing.Count != ids.Count) return BadRequest(new { message = "Có trạm không tồn tại." });
        if (request.Stops.Any(x => x.StopOrder < 1 || x.MinutesFromStart < 0)) return BadRequest(new { message = "StopOrder/MinutesFromStart không hợp lệ." });
        var old = await db.RouteStops.Where(x => x.RouteId == id).ToListAsync(ct);
        db.RouteStops.RemoveRange(old);
        db.RouteStops.AddRange(request.Stops.Select(x => new RouteStop { RouteId = id, StopId = x.StopId, StopOrder = x.StopOrder, MinutesFromStart = x.MinutesFromStart }));
        await db.SaveChangesAsync(ct);
        await AddAudit("Update stops", AuditActionType.Update, AuditModule.Stop, id.ToString(), $"Cập nhật {request.Stops.Count} trạm cho tuyến", ct);
        return Ok(new { message = "Đã cập nhật danh sách và thứ tự trạm.", routeId = id, stops = request.Stops });
    }

    private async Task AddAudit(string action, AuditActionType type, AuditModule module, string target, string details, CancellationToken ct)
    {
        var userId = long.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : (long?)null;
        db.AuditLogs.Add(new AuditLog { AccountId = userId, Username = User.Identity?.Name ?? "anonymous", Action = action, ActionType = type, Module = module, TargetResource = target, IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), Status = AuditStatus.Success, Details = details, CreatedAt = DateTime.UtcNow });
        await db.SaveChangesAsync(ct);
    }
}
