using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.Models;
using SmartBusTicketing.US3.Models;

namespace SmartBusTicketing.US3.Controllers;

[ApiController]
[Route("api/fares")]
public sealed class FaresController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> List([FromQuery] long? routeId, CancellationToken ct)
    {
        var query = db.Fares.AsNoTracking().AsQueryable(); if (routeId.HasValue) query = query.Where(x => x.RouteId == routeId.Value);
        return Ok(await query.OrderByDescending(x => x.EffectiveFrom).Select(x => new { x.Id, x.RouteId, RouteCode = x.BusRoute.Code, RouteName = x.BusRoute.Name, x.TicketType, x.PassengerTypeId, PassengerType = x.PassengerType.Name, x.Price, x.EffectiveFrom }).ToListAsync(ct));
    }

    [HttpGet("{id:long}")]
    [AllowAnonymous]
    public async Task<IActionResult> Get(long id, CancellationToken ct)
    {
        var fare = await db.Fares.AsNoTracking().Where(x => x.Id == id).Select(x => new { x.Id, x.RouteId, RouteCode = x.BusRoute.Code, RouteName = x.BusRoute.Name, x.TicketType, x.PassengerTypeId, PassengerType = x.PassengerType.Name, x.Price, x.EffectiveFrom }).SingleOrDefaultAsync(ct);
        return fare is null ? NotFound(new { message = "Không tìm thấy giá vé." }) : Ok(fare);
    }

    [HttpPost]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> Create(CreateFareRequest request, CancellationToken ct)
    {
        if (request.Price < 0) return BadRequest(new { message = "Giá vé không hợp lệ." });
        if (!await db.BusRoutes.AnyAsync(x => x.Id == request.RouteId, ct)) return BadRequest(new { message = "Tuyến đường không tồn tại." });
        if (!await db.PassengerTypes.AnyAsync(x => x.Id == request.PassengerTypeId, ct)) return BadRequest(new { message = "Loại hành khách không tồn tại." });
        var fare = new Fare { RouteId = request.RouteId, TicketType = request.TicketType, PassengerTypeId = request.PassengerTypeId, Price = request.Price, EffectiveFrom = request.EffectiveFrom };
        db.Fares.Add(fare); await db.SaveChangesAsync(ct); return CreatedAtAction(nameof(Get), new { id = fare.Id }, fare);
    }

    [HttpPut("{id:long}")]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> Update(long id, UpdateFareRequest request, CancellationToken ct)
    {
        var fare = await db.Fares.FindAsync([id], ct); if (fare is null) return NotFound(new { message = "Không tìm thấy giá vé." });
        if (request.Price < 0 || !await db.PassengerTypes.AnyAsync(x => x.Id == request.PassengerTypeId, ct)) return BadRequest(new { message = "Thông tin giá vé không hợp lệ." });
        fare.TicketType = request.TicketType; fare.PassengerTypeId = request.PassengerTypeId; fare.Price = request.Price; fare.EffectiveFrom = request.EffectiveFrom; await db.SaveChangesAsync(ct); return Ok(fare);
    }

    [HttpDelete("{id:long}")]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> Delete(long id, CancellationToken ct)
    {
        var fare = await db.Fares.FindAsync([id], ct); if (fare is null) return NotFound(new { message = "Không tìm thấy giá vé." });
        db.Fares.Remove(fare); await db.SaveChangesAsync(ct); return Ok(new { message = "Đã xóa giá vé." });
    }
}
