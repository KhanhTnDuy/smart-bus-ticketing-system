using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.Models;
using SmartBusTicketing.US3.Models;

namespace SmartBusTicketing.US3.Controllers;

[ApiController]
[Route("api/stops")]
public sealed class StopsController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> List(CancellationToken ct) => Ok(await db.Stops.AsNoTracking().OrderBy(x => x.Name).Select(x => new { x.Id, x.Name, x.Latitude, x.Longitude }).ToListAsync(ct));

    [HttpGet("{id:long}")]
    [AllowAnonymous]
    public async Task<IActionResult> Get(long id, CancellationToken ct)
    {
        var stop = await db.Stops.AsNoTracking().Where(x => x.Id == id).Select(x => new { x.Id, x.Name, x.Latitude, x.Longitude, Routes = x.RouteStops.OrderBy(r => r.StopOrder).Select(r => new { r.RouteId, r.StopOrder, r.MinutesFromStart, r.BusRoute.Code, r.BusRoute.Name }) }).SingleOrDefaultAsync(ct);
        return stop is null ? NotFound(new { message = "Không tìm thấy trạm dừng." }) : Ok(stop);
    }

    [HttpPost]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> Create(CreateStopRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Name)) return BadRequest(new { message = "Tên trạm không được để trống." });
        var stop = new Stop { Name = request.Name.Trim(), Latitude = request.Latitude, Longitude = request.Longitude };
        db.Stops.Add(stop); await db.SaveChangesAsync(ct); return CreatedAtAction(nameof(Get), new { id = stop.Id }, stop);
    }

    [HttpPut("{id:long}")]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> Update(long id, UpdateStopRequest request, CancellationToken ct)
    {
        var stop = await db.Stops.FindAsync([id], ct); if (stop is null) return NotFound(new { message = "Không tìm thấy trạm dừng." });
        stop.Name = request.Name.Trim(); stop.Latitude = request.Latitude; stop.Longitude = request.Longitude; await db.SaveChangesAsync(ct); return Ok(stop);
    }

    [HttpDelete("{id:long}")]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> Delete(long id, CancellationToken ct)
    {
        var stop = await db.Stops.FindAsync([id], ct); if (stop is null) return NotFound(new { message = "Không tìm thấy trạm dừng." });
        if (await db.RouteStops.AnyAsync(x => x.StopId == id, ct)) return Conflict(new { message = "Không thể xóa trạm đang được sử dụng bởi tuyến đường." });
        db.Stops.Remove(stop); await db.SaveChangesAsync(ct); return Ok(new { message = "Đã xóa trạm dừng." });
    }
}
