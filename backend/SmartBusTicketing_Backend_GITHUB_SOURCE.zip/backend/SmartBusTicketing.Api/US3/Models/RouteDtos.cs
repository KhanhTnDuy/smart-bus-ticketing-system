using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.US3.Models;

public sealed record CreateRouteRequest(string Code, string Name, string StartPoint, string EndPoint, decimal DistanceKm, bool Active = true);
public sealed record UpdateRouteRequest(string Code, string Name, string StartPoint, string EndPoint, decimal DistanceKm, bool Active);
public sealed record CreateStopRequest(string Name, decimal Latitude, decimal Longitude);
public sealed record UpdateStopRequest(string Name, decimal Latitude, decimal Longitude);
public sealed record RouteStopItem(long StopId, int StopOrder, int MinutesFromStart);
public sealed record UpdateRouteStopsRequest(List<RouteStopItem> Stops);
public sealed record CreateFareRequest(long RouteId, TicketType TicketType, int PassengerTypeId, decimal Price, DateOnly EffectiveFrom);
public sealed record UpdateFareRequest(TicketType TicketType, int PassengerTypeId, decimal Price, DateOnly EffectiveFrom);
