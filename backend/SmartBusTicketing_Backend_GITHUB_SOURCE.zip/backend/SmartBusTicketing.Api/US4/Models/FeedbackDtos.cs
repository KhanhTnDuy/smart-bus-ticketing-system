using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.US4.Models;

public sealed record CreateFeedbackRequest(
    FeedbackType Type,
    string Subject,
    byte Rating,
    long? RouteId = null,
    long? TripId = null,
    string? ImagePath = null);

public sealed record UpdateFeedbackStatusRequest(FeedbackStatus Status);
