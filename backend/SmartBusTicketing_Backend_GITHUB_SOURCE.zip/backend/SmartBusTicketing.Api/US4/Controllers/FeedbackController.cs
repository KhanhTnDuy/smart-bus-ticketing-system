using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.Models;
using SmartBusTicketing.US4.Models;

namespace SmartBusTicketing.US4.Controllers;

[ApiController]
[Route("api/feedback")]
[Authorize]
public sealed class FeedbackController(AppDbContext db) : ControllerBase
{
    [HttpPost]
    [Authorize(Roles = "PASSENGER")]
    public async Task<IActionResult> Create(CreateFeedbackRequest request, CancellationToken ct)
    {
        if (!TryGetUserId(out var passengerId)) return Unauthorized();
        if (string.IsNullOrWhiteSpace(request.Subject)) return BadRequest(new { message = "Nội dung phản ánh/đánh giá không được để trống." });
        if (request.Type == FeedbackType.Review && (request.Rating < 1 || request.Rating > 5)) return BadRequest(new { message = "Đánh giá chuyến đi phải từ 1 đến 5 sao." });
        if (request.Type == FeedbackType.Complaint && request.Rating > 5) return BadRequest(new { message = "Rating không hợp lệ." });
        if (request.RouteId.HasValue && !await db.BusRoutes.AnyAsync(x => x.Id == request.RouteId.Value, ct)) return BadRequest(new { message = "Tuyến đường không tồn tại." });
        if (request.TripId.HasValue && !await db.Trips.AnyAsync(x => x.Id == request.TripId.Value, ct)) return BadRequest(new { message = "Chuyến đi không tồn tại." });
        var feedback = new Feedback { PassengerId = passengerId, RouteId = request.RouteId, TripId = request.TripId, Type = request.Type, Subject = request.Subject.Trim(), Rating = request.Rating, ImagePath = request.ImagePath, Status = FeedbackStatus.ChuaXuLy };
        db.Feedbacks.Add(feedback);
        db.AuditLogs.Add(new AuditLog { AccountId = passengerId, Username = User.Identity?.Name ?? "passenger", Action = "Submit feedback", ActionType = AuditActionType.FeedbackSubmit, Module = request.Type == FeedbackType.Complaint ? AuditModule.Complaint : AuditModule.Rating, TargetResource = "feedback:new", Status = AuditStatus.Success, Details = feedback.Subject, IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), CreatedAt = DateTime.UtcNow });
        await db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(Get), new { id = feedback.Id }, feedback);
    }

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] FeedbackStatus? status, [FromQuery] FeedbackType? type, CancellationToken ct)
    {
        var isManager = User.IsInRole("ADMIN") || User.IsInRole("MANAGER");
        var query = db.Feedbacks.AsNoTracking().AsQueryable();
        if (!isManager) { if (!TryGetUserId(out var passengerId)) return Unauthorized(); query = query.Where(x => x.PassengerId == passengerId); }
        if (status.HasValue) query = query.Where(x => x.Status == status.Value);
        if (type.HasValue) query = query.Where(x => x.Type == type.Value);
        var data = await query.OrderByDescending(x => x.Id).Select(x => new { x.Id, x.PassengerId, PassengerName = x.Passenger.FullName, x.RouteId, RouteName = x.BusRoute == null ? null : x.BusRoute.Name, x.TripId, x.Type, x.Subject, x.Rating, x.ImagePath, x.Status, x.ProcessedBy, ProcessorName = x.Processor == null ? null : x.Processor.FullName }).ToListAsync(ct);
        return Ok(data);
    }

    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id, CancellationToken ct)
    {
        var isManager = User.IsInRole("ADMIN") || User.IsInRole("MANAGER");
        var query = db.Feedbacks.AsNoTracking().Where(x => x.Id == id); if (!isManager) { if (!TryGetUserId(out var passengerId)) return Unauthorized(); query = query.Where(x => x.PassengerId == passengerId); }
        var item = await query.Select(x => new { x.Id, x.PassengerId, PassengerName = x.Passenger.FullName, x.RouteId, RouteName = x.BusRoute == null ? null : x.BusRoute.Name, x.TripId, x.Type, x.Subject, x.Rating, x.ImagePath, x.Status, x.ProcessedBy, ProcessorName = x.Processor == null ? null : x.Processor.FullName, History = x.History.OrderByDescending(h => h.ChangedAt).Select(h => new { h.Id, h.OldStatus, h.NewStatus, h.ChangedBy, ChangedByName = h.Changer.FullName, h.ChangedAt }) }).SingleOrDefaultAsync(ct);
        return item is null ? NotFound(new { message = "Không tìm thấy phản ánh/đánh giá." }) : Ok(item);
    }

    [HttpPatch("{id:long}/status")]
    [Authorize(Roles = "ADMIN,MANAGER")]
    public async Task<IActionResult> UpdateStatus(long id, UpdateFeedbackStatusRequest request, CancellationToken ct)
    {
        if (!TryGetUserId(out var managerId)) return Unauthorized();
        var feedback = await db.Feedbacks.FindAsync([id], ct); if (feedback is null) return NotFound(new { message = "Không tìm thấy phản ánh." });
        var old = feedback.Status; if (old == request.Status) return Ok(new { message = "Trạng thái không thay đổi.", feedback.Id, feedback.Status });
        feedback.Status = request.Status; feedback.ProcessedBy = managerId;
        db.FeedbackHistories.Add(new FeedbackHistory { FeedbackId = id, OldStatus = old, NewStatus = request.Status, ChangedBy = managerId, ChangedAt = DateTime.UtcNow });
        db.AuditLogs.Add(new AuditLog { AccountId = managerId, Username = User.Identity?.Name ?? "manager", Action = "Change feedback status", ActionType = AuditActionType.StatusChange, Module = AuditModule.Complaint, TargetResource = id.ToString(), Status = AuditStatus.Success, Details = $"{old} -> {request.Status}", IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(), CreatedAt = DateTime.UtcNow });
        await db.SaveChangesAsync(ct); return Ok(new { feedback.Id, feedback.Status, feedback.ProcessedBy });
    }

    private bool TryGetUserId(out long id) => long.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out id);
}
