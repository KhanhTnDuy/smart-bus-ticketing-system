using MySqlConnector;
using SmartBusTicketing.US1.Models;

namespace SmartBusTicketing.US1.Data;

public sealed class AccountRepository(IConfiguration configuration)
{
    private readonly string _connectionString = configuration.GetConnectionString("Default")
        ?? throw new InvalidOperationException("ConnectionStrings:Default is missing.");

    private MySqlConnection CreateConnection() => new(_connectionString);

    public async Task<PagedResult<AccountDto>> GetPagedAsync(int page, int pageSize, string? search, string? role, string? status)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();
        var where = new List<string>();
        if (!string.IsNullOrWhiteSpace(search)) where.Add("(username LIKE @search OR full_name LIKE @search OR email LIKE @search OR phone LIKE @search)");
        if (!string.IsNullOrWhiteSpace(role) && role != "ALL") where.Add("role = @role");
        if (!string.IsNullOrWhiteSpace(status) && status != "ALL") where.Add("status = @status");
        var filter = where.Count == 0 ? "" : " WHERE " + string.Join(" AND ", where);

        await using var count = new MySqlCommand($"SELECT COUNT(*) FROM accounts{filter};", connection);
        AddFilters(count, search, role, status);
        var total = Convert.ToInt64(await count.ExecuteScalarAsync());

        await using var command = new MySqlCommand($"""
            SELECT id, username, full_name, email, phone, role, status, created_at, avatar_url, department
            FROM accounts{filter}
            ORDER BY id DESC LIMIT @limit OFFSET @offset;
            """, connection);
        AddFilters(command, search, role, status);
        command.Parameters.AddWithValue("@limit", pageSize);
        command.Parameters.AddWithValue("@offset", (page - 1) * pageSize);
        var items = new List<AccountDto>();
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync()) items.Add(Map(reader));
        return new PagedResult<AccountDto> { Items = items, Page = page, PageSize = pageSize, TotalCount = total };
    }

    public async Task<AccountDto?> GetByIdAsync(long id)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();
        await using var command = new MySqlCommand("SELECT id, username, full_name, email, phone, role, status, created_at, avatar_url, department FROM accounts WHERE id = @id LIMIT 1;", connection);
        command.Parameters.AddWithValue("@id", id);
        await using var reader = await command.ExecuteReaderAsync();
        return await reader.ReadAsync() ? Map(reader) : null;
    }

    public async Task<(bool Username, bool Email, bool Phone)> FindDuplicatesAsync(string username, string email, string phone, long? exceptId = null)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();
        const string sql = "SELECT username, email, phone FROM accounts WHERE (LOWER(username)=LOWER(@username) OR LOWER(email)=LOWER(@email) OR phone=@phone) AND (@exceptId IS NULL OR id<>@exceptId);";
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@username", username.Trim());
        command.Parameters.AddWithValue("@email", email.Trim().ToLowerInvariant());
        command.Parameters.AddWithValue("@phone", phone.Trim());
        command.Parameters.AddWithValue("@exceptId", exceptId is null ? DBNull.Value : exceptId.Value);
        var usernameExists = false; var emailExists = false; var phoneExists = false;
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            usernameExists |= !reader.IsDBNull(0) && string.Equals(reader.GetString(0), username.Trim(), StringComparison.OrdinalIgnoreCase);
            emailExists |= !reader.IsDBNull(1) && string.Equals(reader.GetString(1), email.Trim(), StringComparison.OrdinalIgnoreCase);
            phoneExists |= !reader.IsDBNull(2) && string.Equals(reader.GetString(2), phone.Trim(), StringComparison.Ordinal);
        }
        return (usernameExists, emailExists, phoneExists);
    }

    public async Task<AccountDto> CreateAsync(CreateAccountRequest request, string actor)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        const string sql = "INSERT INTO accounts (username,password_hash,full_name,email,phone,role,active,status,department,avatar_url) VALUES (@username,@passwordHash,@fullName,@email,@phone,@role,@active,@status,@department,@avatarUrl);";
        await using var command = new MySqlCommand(sql, connection, transaction);
        command.Parameters.AddWithValue("@username", request.Username.Trim());
        command.Parameters.AddWithValue("@passwordHash", BCrypt.Net.BCrypt.HashPassword(request.Password));
        command.Parameters.AddWithValue("@fullName", CleanText(request.FullName));
        command.Parameters.AddWithValue("@email", request.Email.Trim().ToLowerInvariant());
        command.Parameters.AddWithValue("@phone", request.Phone.Trim());
        command.Parameters.AddWithValue("@role", request.Role);
        command.Parameters.AddWithValue("@active", request.Status == "ACTIVE");
        command.Parameters.AddWithValue("@status", request.Status);
        command.Parameters.AddWithValue("@department", (object?)CleanNullable(request.Department) ?? DBNull.Value);
        command.Parameters.AddWithValue("@avatarUrl", (object?)request.AvatarUrl?.Trim() ?? DBNull.Value);
        await command.ExecuteNonQueryAsync();
        var id = command.LastInsertedId;
        await WriteAuditAsync(connection, transaction, actor, "CREATE", "Account", $"Created account {request.Username}", $"USR-{id:D3}");
        await transaction.CommitAsync();
        return (await GetByIdAsync(id))!;
    }

    public async Task<AccountDto?> UpdateAsync(long id, UpdateAccountRequest request, string actor)
    {
        var fields = new List<string>();
        var values = new List<MySqlParameter>();
        if (request.FullName is not null) Add("full_name=@fullName", "@fullName", CleanText(request.FullName));
        if (request.Email is not null) Add("email=@email", "@email", request.Email.Trim().ToLowerInvariant());
        if (request.Phone is not null) Add("phone=@phone", "@phone", request.Phone.Trim());
        if (request.Role is not null) Add("role=@role", "@role", request.Role);
        if (request.Status is not null)
        {
            Add("status=@status", "@status", request.Status);
            Add("active=@active", "@active", request.Status == "ACTIVE");
        }
        if (request.Department is not null) Add("department=@department", "@department", CleanNullable(request.Department) ?? "");
        if (request.AvatarUrl is not null) Add("avatar_url=@avatarUrl", "@avatarUrl", request.AvatarUrl.Trim());
        if (fields.Count == 0) return await GetByIdAsync(id);

        await using var connection = CreateConnection();
        await connection.OpenAsync();
        await using var command = new MySqlCommand($"UPDATE accounts SET {string.Join(",", fields)} WHERE id=@id;", connection);
        foreach (var value in values) command.Parameters.Add(value);
        command.Parameters.AddWithValue("@id", id);
        if (await command.ExecuteNonQueryAsync() == 0) return null;
        await WriteAuditAsync(connection, null, actor, "UPDATE", "Account", $"Updated account USR-{id:D3}", $"USR-{id:D3}");
        return await GetByIdAsync(id);

        void Add(string field, string parameter, object value) { fields.Add(field); values.Add(new MySqlParameter(parameter, value)); }
    }

    public async Task<(bool Found, string? OldRole)> AssignRoleAsync(long id, string newRole, string actor)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        string? oldRole;
        await using (var find = new MySqlCommand("SELECT role FROM accounts WHERE id=@id FOR UPDATE;", connection, transaction))
        {
            find.Parameters.AddWithValue("@id", id);
            var result = await find.ExecuteScalarAsync();
            if (result is null) return (false, null);
            oldRole = Convert.ToString(result);
        }
        await using (var update = new MySqlCommand("UPDATE accounts SET role=@role WHERE id=@id;", connection, transaction))
        {
            update.Parameters.AddWithValue("@role", newRole); update.Parameters.AddWithValue("@id", id);
            await update.ExecuteNonQueryAsync();
        }
        await WriteAuditAsync(connection, transaction, actor, "STATUS_CHANGE", "Role", $"Role changed from {oldRole} to {newRole}", $"USR-{id:D3}");
        await transaction.CommitAsync();
        return (true, oldRole);
    }

    public async Task<bool> IsLastActiveAdminAsync(long id)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();
        await using var command = new MySqlCommand("SELECT COUNT(*) FROM accounts WHERE role='ADMIN' AND status='ACTIVE' AND id<>@id;", connection);
        command.Parameters.AddWithValue("@id", id);
        return Convert.ToInt64(await command.ExecuteScalarAsync()) == 0;
    }

    public async Task<bool> SoftDeleteAsync(long id, string actor)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        await using var update = new MySqlCommand("UPDATE accounts SET status='INACTIVE', active=FALSE WHERE id=@id AND status<>'INACTIVE';", connection, transaction);
        update.Parameters.AddWithValue("@id", id);
        if (await update.ExecuteNonQueryAsync() == 0) return false;
        await WriteAuditAsync(connection, transaction, actor, "DELETE", "Account", $"Soft-deleted account USR-{id:D3}", $"USR-{id:D3}");
        await transaction.CommitAsync();
        return true;
    }

    public async Task<bool> HasActiveTripsAsync(long id)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();
        const string sql = "SELECT COUNT(*) FROM trip_staff ts JOIN trips t ON t.id=ts.trip_id WHERE ts.account_id=@id AND ts.duty='DRIVER' AND t.status IN ('SCHEDULED','RUNNING','DELAYED');";
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", id);
        return Convert.ToInt64(await command.ExecuteScalarAsync()) > 0;
    }

    public async Task<(long Id, string Username, string PasswordHash, string Role, string Status, string FullName, string Email, string Phone, DateTime CreatedAt, string? Department, string? AvatarUrl)?> FindForLoginAsync(string identity)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync();
        const string sql = "SELECT id,username,password_hash,role,status,full_name,email,phone,created_at,department,avatar_url FROM accounts WHERE LOWER(username)=LOWER(@identity) OR LOWER(email)=LOWER(@identity) LIMIT 1;";
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@identity", identity.Trim());
        await using var reader = await command.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) return null;
        return (reader.GetInt64("id"), reader.GetString("username"), reader.GetString("password_hash"), reader.GetString("role"), reader.GetString("status"), reader.GetString("full_name"), reader.GetString("email"), reader.GetString("phone"), reader.GetDateTime("created_at"), ReadNullable(reader, "department"), ReadNullable(reader, "avatar_url"));
    }

    public async Task WriteLoginAuditAsync(long id, string username, string action, string status, string? ip, string? details)
    {
        await using var connection = CreateConnection(); await connection.OpenAsync();
        await using var command = new MySqlCommand("INSERT INTO audit_logs(account_id,username,action,action_type,module,ip_address,status,details) VALUES(@id,@username,@action,@type,'Auth',@ip,@status,@details);", connection);
        command.Parameters.AddWithValue("@id", id); command.Parameters.AddWithValue("@username", username); command.Parameters.AddWithValue("@action", action);
        command.Parameters.AddWithValue("@type", action); command.Parameters.AddWithValue("@ip", (object?)ip ?? DBNull.Value); command.Parameters.AddWithValue("@status", status);
        command.Parameters.AddWithValue("@details", (object?)details ?? DBNull.Value); await command.ExecuteNonQueryAsync();
    }

    private static async Task WriteAuditAsync(MySqlConnection connection, MySqlTransaction? transaction, string actor, string actionType, string module, string details, string target)
    {
        const string sql = "INSERT INTO audit_logs(account_id,username,action,action_type,module,target_resource,status,details) VALUES(NULL,@username,@action,@type,@module,@target,'SUCCESS',@details);";
        await using var command = new MySqlCommand(sql, connection, transaction);
        command.Parameters.AddWithValue("@username", actor); command.Parameters.AddWithValue("@action", details); command.Parameters.AddWithValue("@type", actionType); command.Parameters.AddWithValue("@module", module);
        command.Parameters.AddWithValue("@target", target); command.Parameters.AddWithValue("@details", details); await command.ExecuteNonQueryAsync();
    }

    private static void AddFilters(MySqlCommand command, string? search, string? role, string? status)
    {
        if (!string.IsNullOrWhiteSpace(search)) command.Parameters.AddWithValue("@search", $"%{search.Trim()}%");
        if (!string.IsNullOrWhiteSpace(role) && role != "ALL") command.Parameters.AddWithValue("@role", role);
        if (!string.IsNullOrWhiteSpace(status) && status != "ALL") command.Parameters.AddWithValue("@status", status);
    }

    private static AccountDto Map(MySqlDataReader reader) => new()
    {
        Id = $"USR-{reader.GetInt64("id"):D3}", Username = reader.GetString("username"), FullName = reader.GetString("full_name"),
        Email = ReadNullable(reader, "email") ?? "", Phone = ReadNullable(reader, "phone") ?? "", Role = reader.GetString("role"),
        Status = reader.GetString("status"), CreatedAt = reader.GetDateTime("created_at").ToString("yyyy-MM-dd HH:mm:ss"),
        AvatarUrl = ReadNullable(reader, "avatar_url"), Department = ReadNullable(reader, "department")
    };

    private static string? ReadNullable(MySqlDataReader reader, string column) => reader.IsDBNull(reader.GetOrdinal(column)) ? null : reader.GetString(column);
    private static string CleanText(string value) => new(value.Trim().Where(c => !char.IsControl(c)).ToArray());
    private static string? CleanNullable(string? value) => string.IsNullOrWhiteSpace(value) ? null : CleanText(value);
}
