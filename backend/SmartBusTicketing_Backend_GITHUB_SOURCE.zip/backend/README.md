# Smart Bus Ticketing System - Backend

ASP.NET Core Web API (.NET 10) + Entity Framework Core + MySQL.

## Included User Stories

- US1 - Account Management
- US2 - Audit / Access Logs
- US3 - Route, Stop and Fare Management
- US4 - Passenger Feedback / Complaint Management

## Structure

```text
backend/
├── database/
│   ├── schema.sql
│   ├── ERD.md
│   ├── US1_AccountManagementFields.sql
│   └── US2_AuditLogs.sql
│
├── SmartBusTicketing.Api/
│   ├── Controllers/
│   │   ├── HealthController.cs
│   │   └── AuditLogsController.cs
│   ├── US1/
│   │   ├── Controllers/
│   │   ├── Models/
│   │   ├── Services/
│   │   ├── Data/
│   │   └── Middleware/
│   ├── US3/
│   │   ├── Controllers/
│   │   └── Models/
│   ├── US4/
│   │   ├── Controllers/
│   │   └── Models/
│   ├── Models/
│   ├── DTOs/
│   ├── Services/
│   ├── Data/
│   │   └── Migrations/
│   ├── Properties/
│   ├── Program.cs
│   ├── appsettings.json
│   └── SmartBusTicketing.Api.csproj
│
├── SmartBusTicketing.slnx
└── .gitignore
```

## Main API endpoints

### US1 - Account Management
- POST `/api/auth/login`
- POST `/api/auth/logout`
- GET `/api/accounts`
- GET `/api/accounts/{id}`
- POST `/api/accounts`
- PUT `/api/accounts/{id}`
- PATCH `/api/accounts/{id}/role`
- PATCH `/api/accounts/{id}/status`
- DELETE `/api/accounts/{id}`

### US2 - Audit Logs
- GET `/api/audit-logs`
- GET `/api/audit-logs/{id}`

### US3 - Routes / Stops / Fares
- GET/POST `/api/routes`
- GET/PUT/DELETE `/api/routes/{id}`
- PUT `/api/routes/{id}/stops`
- GET/POST `/api/stops`
- GET/PUT/DELETE `/api/stops/{id}`
- GET/POST `/api/fares`
- GET/PUT/DELETE `/api/fares/{id}`

### US4 - Feedback
- POST `/api/feedback`
- GET `/api/feedback`
- GET `/api/feedback/{id}`
- PATCH `/api/feedback/{id}/status`

## Run locally

1. Install .NET 10 SDK and MySQL 8.
2. Create database `smart_bus_ticketing`.
3. Import `database/schema.sql` if using the SQL schema setup.
4. Check the connection string in `SmartBusTicketing.Api/appsettings.json`.
5. Open `SmartBusTicketing.slnx` or `SmartBusTicketing.Api/SmartBusTicketing.Api.csproj` in Visual Studio.
6. Restore NuGet packages and run the API.

Default frontend CORS origins:
- http://localhost:5173
- http://127.0.0.1:5173

Do not commit real database passwords or production JWT secrets. Use local/user secrets or environment-specific configuration for deployment.
