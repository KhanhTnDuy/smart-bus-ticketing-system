# Common Backend API

Shared ASP.NET Core project files, database context/models/services, DTOs and all controllers.
