using Microsoft.AspNetCore.Mvc;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/health")]
public sealed class HealthController : ControllerBase
{
    [HttpGet]
    public IActionResult Get() => Ok(new { status = "OK", service = "SmartBusTicketing Group API", version = "1.0" });
}
