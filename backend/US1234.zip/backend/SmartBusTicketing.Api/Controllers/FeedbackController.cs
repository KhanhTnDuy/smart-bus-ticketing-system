using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.DTOs;
using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/feedback")]
public class FeedbackController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    [Authorize(Roles = "Admin,Manager")]
    public async Task<IActionResult> List([FromQuery] FeedbackStatus? status, [FromQuery] FeedbackType? type)
    {
        var q = db.Feedbacks.AsNoTracking().Include(f => f.Passenger).Include(f => f.BusRoute).Include(f => f.Trip).AsQueryable();
        if (status.HasValue) q = q.Where(f => f.Status == status.Value); if (type.HasValue) q = q.Where(f => f.Type == type.Value);
        return Ok(await q.OrderByDescending(f => f.Id).ToListAsync());
    }

    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id)
    {
        var f = await db.Feedbacks.AsNoTracking().Include(x => x.Passenger).Include(x => x.BusRoute).Include(x => x.Trip).Include(x => x.History).FirstOrDefaultAsync(x => x.Id == id);
        return f is null ? NotFound(new { message = "Không tìm thấy phản ánh/đánh giá." }) : Ok(f);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateFeedbackRequest request)
    {
        if (!await db.Accounts.AnyAsync(a => a.Id == request.PassengerId)) return BadRequest(new { message = "PassengerId không tồn tại." });
        if (request.Rating is < 1 or > 5) return BadRequest(new { message = "Rating phải từ 1 đến 5." });
        if (request.RouteId.HasValue && !await db.BusRoutes.AnyAsync(r => r.Id == request.RouteId)) return BadRequest(new { message = "RouteId không tồn tại." });
        if (request.TripId.HasValue && !await db.Trips.AnyAsync(t => t.Id == request.TripId)) return BadRequest(new { message = "TripId không tồn tại." });
        var f = new Feedback { PassengerId = request.PassengerId, Type = request.Type, Subject = request.Subject.Trim(), Rating = request.Rating, RouteId = request.RouteId, TripId = request.TripId, ImagePath = request.ImagePath, Status = FeedbackStatus.ChuaXuLy };
        db.Feedbacks.Add(f); await db.SaveChangesAsync();
        db.AuditLogs.Add(new AuditLog { AccountId = request.PassengerId, Username = (await db.Accounts.FindAsync(request.PassengerId))!.Username, Action = "SUBMIT FEEDBACK", ActionType = AuditActionType.FeedbackSubmit, Status = AuditStatus.Success, TargetResource = $"feedback/{f.Id}", CreatedAt = DateTime.UtcNow });
        await db.SaveChangesAsync(); return CreatedAtAction(nameof(Get), new { id = f.Id }, f);
    }

    [Authorize(Roles = "Admin,Manager")]
    [HttpPatch("{id:long}/status")]
    public async Task<IActionResult> UpdateStatus(long id, UpdateFeedbackStatusRequest request)
    {
        var f = await db.Feedbacks.FindAsync(id); if (f is null) return NotFound(new { message = "Không tìm thấy phản ánh/đánh giá." });
        if (!await db.Accounts.AnyAsync(a => a.Id == request.ChangedBy)) return BadRequest(new { message = "ChangedBy không tồn tại." });
        var old = f.Status; f.Status = request.Status; f.ProcessedBy = request.ChangedBy;
        db.FeedbackHistories.Add(new FeedbackHistory { FeedbackId = f.Id, OldStatus = old, NewStatus = request.Status, ChangedBy = request.ChangedBy, ChangedAt = DateTime.UtcNow });
        db.AuditLogs.Add(new AuditLog { AccountId = request.ChangedBy, Username = (await db.Accounts.FindAsync(request.ChangedBy))!.Username, Action = "UPDATE FEEDBACK STATUS", ActionType = AuditActionType.StatusChange, Status = AuditStatus.Success, TargetResource = $"feedback/{id}", Details = request.Note, CreatedAt = DateTime.UtcNow });
        await db.SaveChangesAsync(); return Ok(f);
    }
}
