using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/audit-logs")]
[Authorize(Roles = "Admin,Manager")]
public class AuditLogsController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? username, [FromQuery] string? actionType, [FromQuery] string? status, [FromQuery] DateTime? from, [FromQuery] DateTime? to)
    {
        var q = db.AuditLogs.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(username)) q = q.Where(x => x.Username.Contains(username));
        if (!string.IsNullOrWhiteSpace(actionType) && Enum.TryParse<SmartBusTicketing.Api.Models.AuditActionType>(actionType, true, out var at)) q = q.Where(x => x.ActionType == at);
        if (!string.IsNullOrWhiteSpace(status) && Enum.TryParse<SmartBusTicketing.Api.Models.AuditStatus>(status, true, out var st)) q = q.Where(x => x.Status == st);
        if (from.HasValue) q = q.Where(x => x.CreatedAt >= from.Value);
        if (to.HasValue) q = q.Where(x => x.CreatedAt <= to.Value);
        return Ok(await q.OrderByDescending(x => x.CreatedAt).Take(500).ToListAsync());
    }

    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id)
    {
        var log = await db.AuditLogs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return log is null ? NotFound(new { message = "Không tìm thấy audit log." }) : Ok(log);
    }
}
