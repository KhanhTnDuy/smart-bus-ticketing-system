using System.Security.Claims;
using BCrypt.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.DTOs;
using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/accounts")]
[Authorize(Roles = "Admin")]
public class AccountsController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? search, [FromQuery] AccountRole? role, [FromQuery] bool? active)
    {
        var q = db.Accounts.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(search))
            q = q.Where(a => a.Username.Contains(search) || a.FullName.Contains(search) || (a.Email != null && a.Email.Contains(search)));
        if (role.HasValue) q = q.Where(a => a.Role == role.Value);
        if (active.HasValue) q = q.Where(a => a.Active == active.Value);
        return Ok(await q.OrderByDescending(a => a.Id).Select(a => new
        {
            a.Id, a.Username, a.FullName, a.Email, a.Phone, Role = a.Role.ToString(), a.Active, a.CreatedAt, a.UpdatedAt
        }).ToListAsync());
    }

    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id)
    {
        var a = await db.Accounts.AsNoTracking().Where(x => x.Id == id).Select(x => new
        {
            x.Id, x.Username, x.FullName, x.Email, x.Phone, Role = x.Role.ToString(), x.Active, x.CreatedAt, x.UpdatedAt
        }).FirstOrDefaultAsync();
        return a is null ? NotFound(new { message = "Không tìm thấy tài khoản." }) : Ok(a);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateAccountRequest request)
    {
        if (await db.Accounts.AnyAsync(a => a.Username == request.Username)) return Conflict(new { message = "Username đã tồn tại." });
        if (!string.IsNullOrWhiteSpace(request.Email) && await db.Accounts.AnyAsync(a => a.Email == request.Email)) return Conflict(new { message = "Email đã tồn tại." });
        if (!string.IsNullOrWhiteSpace(request.Phone) && await db.Accounts.AnyAsync(a => a.Phone == request.Phone)) return Conflict(new { message = "Số điện thoại đã tồn tại." });

        var now = DateTime.UtcNow;
        var account = new Account
        {
            Username = request.Username.Trim(),
            PasswordHash = BCrypt.HashPassword(request.Password),
            FullName = request.FullName.Trim(),
            Email = request.Email,
            Phone = request.Phone,
            Role = request.Role,
            Active = request.Active,
            CreatedAt = now,
            UpdatedAt = now
        };
        db.Accounts.Add(account);
        await db.SaveChangesAsync();
        await Audit(account, "CREATE ACCOUNT", AuditActionType.Create, $"Created account {account.Id}");
        return CreatedAtAction(nameof(Get), new { id = account.Id }, new { account.Id, account.Username, account.FullName, account.Email, account.Phone, Role = account.Role.ToString(), account.Active });
    }

    [HttpPut("{id:long}")]
    public async Task<IActionResult> Update(long id, UpdateAccountRequest request)
    {
        var account = await db.Accounts.FindAsync(id);
        if (account is null) return NotFound(new { message = "Không tìm thấy tài khoản." });
        if (request.Email is not null && request.Email != account.Email && await db.Accounts.AnyAsync(a => a.Id != id && a.Email == request.Email)) return Conflict(new { message = "Email đã tồn tại." });
        if (request.Phone is not null && request.Phone != account.Phone && await db.Accounts.AnyAsync(a => a.Id != id && a.Phone == request.Phone)) return Conflict(new { message = "Số điện thoại đã tồn tại." });

        if (request.FullName is not null) account.FullName = request.FullName.Trim();
        if (request.Email is not null) account.Email = request.Email;
        if (request.Phone is not null) account.Phone = request.Phone;
        if (request.Role.HasValue) account.Role = request.Role.Value;
        if (request.Active.HasValue) account.Active = request.Active.Value;
        if (!string.IsNullOrWhiteSpace(request.Password)) account.PasswordHash = BCrypt.HashPassword(request.Password);
        account.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        await Audit(account, "UPDATE ACCOUNT", AuditActionType.Update, $"Updated account {id}");
        return Ok(new { account.Id, account.Username, account.FullName, account.Email, account.Phone, Role = account.Role.ToString(), account.Active, account.UpdatedAt });
    }

    [HttpPatch("{id:long}/role")]
    public async Task<IActionResult> AssignRole(long id, AssignRoleRequest request)
    {
        var account = await db.Accounts.FindAsync(id);
        if (account is null) return NotFound(new { message = "Không tìm thấy tài khoản." });
        account.Role = request.Role;
        account.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        await Audit(account, "ASSIGN ROLE", AuditActionType.StatusChange, $"Role={request.Role}");
        return Ok(new { account.Id, Role = account.Role.ToString(), account.Active });
    }

    [HttpDelete("{id:long}")]
    public async Task<IActionResult> Delete(long id)
    {
        var account = await db.Accounts.FindAsync(id);
        if (account is null) return NotFound(new { message = "Không tìm thấy tài khoản." });
        account.Active = false;
        account.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        await Audit(account, "DEACTIVATE ACCOUNT", AuditActionType.Delete, $"Account {id} set inactive");
        return Ok(new { message = "Tài khoản đã được chuyển sang INACTIVE." });
    }

    private async Task Audit(Account account, string action, AuditActionType type, string details)
    {
        db.AuditLogs.Add(new AuditLog
        {
            AccountId = account.Id,
            Username = account.Username,
            Action = action,
            ActionType = type,
            Status = AuditStatus.Success,
            TargetResource = $"accounts/{account.Id}",
            IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
            UserAgent = Request.Headers.UserAgent.ToString(),
            Details = details,
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
    }
}
