using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.DTOs;
using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/routes")]
public class RoutesController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List() => Ok(await db.BusRoutes.AsNoTracking().Include(r => r.RouteStops).ThenInclude(rs => rs.Stop).OrderBy(r => r.Code).ToListAsync());

    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id)
    {
        var route = await db.BusRoutes.AsNoTracking().Include(r => r.RouteStops).ThenInclude(rs => rs.Stop).Include(r => r.Fares).FirstOrDefaultAsync(r => r.Id == id);
        return route is null ? NotFound(new { message = "Không tìm thấy tuyến." }) : Ok(route);
    }

    [Authorize(Roles = "Admin,Manager")]
    [HttpPost]
    public async Task<IActionResult> Create(CreateRouteRequest request)
    {
        if (await db.BusRoutes.AnyAsync(r => r.Code == request.Code)) return Conflict(new { message = "Mã tuyến đã tồn tại." });
        var route = new BusRoute { Code = request.Code.Trim(), Name = request.Name.Trim(), StartPoint = request.StartPoint.Trim(), EndPoint = request.EndPoint.Trim(), DistanceKm = request.DistanceKm, Active = request.Active };
        db.BusRoutes.Add(route); await db.SaveChangesAsync(); return CreatedAtAction(nameof(Get), new { id = route.Id }, route);
    }

    [Authorize(Roles = "Admin,Manager")]
    [HttpPut("{id:long}")]
    public async Task<IActionResult> Update(long id, UpdateRouteRequest request)
    {
        var route = await db.BusRoutes.FindAsync(id); if (route is null) return NotFound(new { message = "Không tìm thấy tuyến." });
        if (request.Code is not null && request.Code != route.Code && await db.BusRoutes.AnyAsync(r => r.Id != id && r.Code == request.Code)) return Conflict(new { message = "Mã tuyến đã tồn tại." });
        if (request.Code is not null) route.Code = request.Code.Trim(); if (request.Name is not null) route.Name = request.Name.Trim(); if (request.StartPoint is not null) route.StartPoint = request.StartPoint.Trim(); if (request.EndPoint is not null) route.EndPoint = request.EndPoint.Trim(); if (request.DistanceKm.HasValue) route.DistanceKm = request.DistanceKm.Value; if (request.Active.HasValue) route.Active = request.Active.Value;
        await db.SaveChangesAsync(); return Ok(route);
    }

    [Authorize(Roles = "Admin,Manager")]
    [HttpDelete("{id:long}")]
    public async Task<IActionResult> Delete(long id)
    {
        var route = await db.BusRoutes.FindAsync(id); if (route is null) return NotFound(new { message = "Không tìm thấy tuyến." });
        route.Active = false; await db.SaveChangesAsync(); return Ok(new { message = "Tuyến đã được vô hiệu hóa." });
    }

    [Authorize(Roles = "Admin,Manager")]
    [HttpPut("{id:long}/stops")]
    public async Task<IActionResult> ReplaceStops(long id, List<RouteStopItem> items)
    {
        var route = await db.BusRoutes.FindAsync(id); if (route is null) return NotFound(new { message = "Không tìm thấy tuyến." });
        if (items.Count == 0) return BadRequest(new { message = "Danh sách trạm không được rỗng." });
        if (items.GroupBy(x => x.StopId).Any(g => g.Count() > 1) || items.Select(x => x.StopOrder).Distinct().Count() != items.Count) return BadRequest(new { message = "StopId và StopOrder không được trùng." });
        var stopIds = items.Select(x => x.StopId).ToHashSet();
        var existing = await db.Stops.Where(s => stopIds.Contains(s.Id)).Select(s => s.Id).ToListAsync();
        if (existing.Count != stopIds.Count) return BadRequest(new { message = "Có StopId không tồn tại." });
        db.RouteStops.RemoveRange(await db.RouteStops.Where(x => x.RouteId == id).ToListAsync());
        db.RouteStops.AddRange(items.Select(x => new RouteStop { RouteId = id, StopId = x.StopId, StopOrder = x.StopOrder, MinutesFromStart = x.MinutesFromStart }));
        await db.SaveChangesAsync(); return Ok(await db.RouteStops.AsNoTracking().Where(x => x.RouteId == id).OrderBy(x => x.StopOrder).ToListAsync());
    }
}
