using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BCrypt.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.DTOs;
using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController(AppDbContext db, IConfiguration configuration) : ControllerBase
{
    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var account = await db.Accounts.FirstOrDefaultAsync(a =>
            a.Username == request.Identity || a.Email == request.Identity || a.Phone == request.Identity);

        if (account is null || !account.Active || !BCrypt.Verify(request.Password, account.PasswordHash))
        {
            if (account is not null)
                await WriteAudit(account, "LOGIN", AuditActionType.Login, AuditStatus.Failure, "Invalid credentials");
            return Unauthorized(new { message = "Tài khoản hoặc mật khẩu không chính xác hoặc đã bị vô hiệu hóa." });
        }

        var key = configuration["Jwt:Key"] ?? throw new InvalidOperationException("Jwt:Key is missing.");
        var issuer = configuration["Jwt:Issuer"] ?? "SmartBusTicketing";
        var audience = configuration["Jwt:Audience"] ?? "SmartBusTicketing.Client";
        var expires = DateTime.UtcNow.AddHours(2);
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, account.Id.ToString()),
            new Claim(ClaimTypes.NameIdentifier, account.Id.ToString()),
            new Claim(ClaimTypes.Name, account.Username),
            new Claim(ClaimTypes.Role, account.Role.ToString())
        };
        var credentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)), SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(issuer, audience, claims, expires: expires, signingCredentials: credentials);

        await WriteAudit(account, "LOGIN", AuditActionType.Login, AuditStatus.Success, null);
        return Ok(new
        {
            accessToken = new JwtSecurityTokenHandler().WriteToken(token),
            expiresAt = expires,
            user = new { account.Id, account.Username, account.FullName, account.Email, account.Phone, role = account.Role.ToString(), account.Active }
        });
    }

    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        if (long.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id))
        {
            var account = await db.Accounts.FindAsync(id);
            if (account is not null)
                await WriteAudit(account, "LOGOUT", AuditActionType.Logout, AuditStatus.Success, null);
        }
        return Ok(new { message = "Đăng xuất thành công." });
    }

    private async Task WriteAudit(Account account, string action, AuditActionType type, AuditStatus status, string? details)
    {
        db.AuditLogs.Add(new AuditLog
        {
            AccountId = account.Id,
            Username = account.Username,
            Action = action,
            ActionType = type,
            Status = status,
            IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
            UserAgent = Request.Headers.UserAgent.ToString(),
            Details = details,
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();
    }
}
