using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.DTOs;
using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/fares")]
public class FaresController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] long? routeId) { var q = db.Fares.AsNoTracking().Include(f => f.BusRoute).Include(f => f.PassengerType).AsQueryable(); if (routeId.HasValue) q = q.Where(f => f.RouteId == routeId); return Ok(await q.OrderBy(f => f.RouteId).ThenBy(f => f.EffectiveFrom).ToListAsync()); }
    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id) { var f = await db.Fares.AsNoTracking().Include(x => x.BusRoute).Include(x => x.PassengerType).FirstOrDefaultAsync(x => x.Id == id); return f is null ? NotFound(new { message = "Không tìm thấy giá vé." }) : Ok(f); }
    [Authorize(Roles = "Admin,Manager")]
    [HttpPost]
    public async Task<IActionResult> Create(CreateFareRequest request) { if (!await db.BusRoutes.AnyAsync(r => r.Id == request.RouteId)) return BadRequest(new { message = "RouteId không tồn tại." }); if (!await db.PassengerTypes.AnyAsync(p => p.Id == request.PassengerTypeId)) return BadRequest(new { message = "PassengerTypeId không tồn tại." }); if (request.Price.Value < 0) return BadRequest(new { message = "Price phải >= 0." }); var f = new Fare { RouteId = request.RouteId, TicketType = request.TicketType, PassengerTypeId = request.PassengerTypeId, Price = request.Price, EffectiveFrom = request.EffectiveFrom }; db.Fares.Add(f); await db.SaveChangesAsync(); return CreatedAtAction(nameof(Get), new { id = f.Id }, f); }
    [Authorize(Roles = "Admin,Manager")]
    [HttpPut("{id:long}")]
    public async Task<IActionResult> Update(long id, UpdateFareRequest request) { var f = await db.Fares.FindAsync(id); if (f is null) return NotFound(new { message = "Không tìm thấy giá vé." }); if (request.TicketType.HasValue) f.TicketType = request.TicketType.Value; if (request.PassengerTypeId.HasValue) f.PassengerTypeId = request.PassengerTypeId.Value; if (request.Price.HasValue) { if (request.Price.Value < 0) return BadRequest(new { message = "Price phải >= 0." }); f.Price = request.Price.Value; } if (request.EffectiveFrom.HasValue) f.EffectiveFrom = request.EffectiveFrom.Value; await db.SaveChangesAsync(); return Ok(f); }
    [Authorize(Roles = "Admin,Manager")]
    [HttpDelete("{id:long}")]
    public async Task<IActionResult> Delete(long id) { var f = await db.Fares.FindAsync(id); if (f is null) return NotFound(new { message = "Không tìm thấy giá vé." }); db.Fares.Remove(f); await db.SaveChangesAsync(); return NoContent(); }
}
