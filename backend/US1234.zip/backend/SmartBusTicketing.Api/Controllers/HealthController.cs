using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/health")]
public class HealthController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var database = false;
        try { database = await db.Database.CanConnectAsync(); }
        catch { }
        return Ok(new { status = "ok", database, time = DateTime.UtcNow });
    }
}
