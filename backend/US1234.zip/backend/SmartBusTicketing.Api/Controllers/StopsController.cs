using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.DTOs;
using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.Controllers;

[ApiController]
[Route("api/stops")]
public class StopsController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List() => Ok(await db.Stops.AsNoTracking().OrderBy(s => s.Name).ToListAsync());

    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id) { var s = await db.Stops.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id); return s is null ? NotFound(new { message = "Không tìm thấy trạm." }) : Ok(s); }

    [Authorize(Roles = "Admin,Manager")]
    [HttpPost]
    public async Task<IActionResult> Create(CreateStopRequest request) { var s = new Stop { Name = request.Name.Trim(), Latitude = request.Latitude, Longitude = request.Longitude }; db.Stops.Add(s); await db.SaveChangesAsync(); return CreatedAtAction(nameof(Get), new { id = s.Id }, s); }

    [Authorize(Roles = "Admin,Manager")]
    [HttpPut("{id:long}")]
    public async Task<IActionResult> Update(long id, UpdateStopRequest request) { var s = await db.Stops.FindAsync(id); if (s is null) return NotFound(new { message = "Không tìm thấy trạm." }); if (request.Name is not null) s.Name = request.Name.Trim(); if (request.Latitude.HasValue) s.Latitude = request.Latitude.Value; if (request.Longitude.HasValue) s.Longitude = request.Longitude.Value; await db.SaveChangesAsync(); return Ok(s); }

    [Authorize(Roles = "Admin,Manager")]
    [HttpDelete("{id:long}")]
    public async Task<IActionResult> Delete(long id) { var s = await db.Stops.FindAsync(id); if (s is null) return NotFound(new { message = "Không tìm thấy trạm." }); if (await db.RouteStops.AnyAsync(x => x.StopId == id)) return Conflict(new { message = "Không thể xóa trạm đang thuộc tuyến." }); db.Stops.Remove(s); await db.SaveChangesAsync(); return NoContent(); }
}
