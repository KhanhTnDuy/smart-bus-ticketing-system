using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.DTOs;

public record LoginRequest(string Identity, string Password);

public record CreateAccountRequest(
    string Username,
    string Password,
    string FullName,
    string? Email,
    string? Phone,
    AccountRole Role = AccountRole.Passenger,
    bool Active = true);

public record UpdateAccountRequest(
    string? FullName,
    string? Email,
    string? Phone,
    AccountRole? Role,
    bool? Active,
    string? Password);

public record AssignRoleRequest(AccountRole Role);

public record CreateRouteRequest(
    string Code,
    string Name,
    string StartPoint,
    string EndPoint,
    decimal DistanceKm,
    bool Active = true);

public record UpdateRouteRequest(
    string? Code,
    string? Name,
    string? StartPoint,
    string? EndPoint,
    decimal? DistanceKm,
    bool? Active);

public record CreateStopRequest(string Name, decimal Latitude, decimal Longitude);
public record UpdateStopRequest(string? Name, decimal? Latitude, decimal? Longitude);

public record RouteStopItem(long StopId, int StopOrder, int MinutesFromStart = 0);

public record CreateFareRequest(
    long RouteId,
    TicketType TicketType,
    int PassengerTypeId,
    decimal Price,
    DateOnly EffectiveFrom);

public record UpdateFareRequest(
    TicketType? TicketType,
    int? PassengerTypeId,
    decimal? Price,
    DateOnly? EffectiveFrom);

public record CreateFeedbackRequest(
    long PassengerId,
    FeedbackType Type,
    string Subject,
    byte Rating,
    long? RouteId,
    long? TripId,
    string? ImagePath);

public record UpdateFeedbackStatusRequest(
    FeedbackStatus Status,
    long ChangedBy,
    string? Note);
