# Smart Bus Ticketing System - Backend

Backend này được dựng lại trực tiếp từ backend gốc đã cung cấp, giữ nguyên database, Models, EF Core DbContext và migrations hiện có.

## User Stories đã tích hợp

- US1 - Account Management: login/logout, tạo/sửa/xóa mềm tài khoản, phân quyền.
- US2 - Audit Logs: xem danh sách và chi tiết nhật ký thao tác.
- US3 - Route / Stop / Fare: quản lý tuyến, trạm, giá vé và thứ tự trạm trên tuyến.
- US4 - Feedback: passenger gửi complaint/review; manager/admin xem và cập nhật trạng thái.

## Database

Database gốc nằm tại `database/schema.sql` và ERD tại `database/ERD.md`.

## Chạy API

1. Tạo database bằng `database/schema.sql` hoặc dùng EF Core migrations của project.
2. Kiểm tra `SmartBusTicketing.Api/appsettings.json` và đổi connection string/JWT secret cho môi trường thật.
3. Chạy:

```bash
dotnet restore
dotnet run --project SmartBusTicketing.Api
```

## Một số endpoint

- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET|POST /api/accounts`
- `PUT|PATCH|DELETE /api/accounts/{id}`
- `GET /api/audit-logs`
- `GET|POST /api/routes`
- `PUT|DELETE /api/routes/{id}`
- `PUT /api/routes/{id}/stops`
- `GET|POST /api/stops`
- `GET|POST /api/fares`
- `GET|POST /api/feedback`
- `PATCH /api/feedback/{id}/status`
- `GET /api/health`

> `appsettings.json` hiện chứa JWT secret mẫu để project chạy demo. Không dùng secret này cho production.
