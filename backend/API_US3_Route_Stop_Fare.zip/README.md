# US3

US3 - Route, Stop and Fare Management.

Project path: `backend/SmartBusTicketing.Api/`
This ZIP is a self-contained copy of the current API structure with the selected User Story controllers.
