using Microsoft.EntityFrameworkCore;
using SmartBusTicketing.Api.Data;
using SmartBusTicketing.Api.DTOs;
using SmartBusTicketing.Api.Models;

namespace SmartBusTicketing.Api.Services;

public interface IAuditLogService
{
    Task<AuditLogListResponse> GetAsync(string? search, string? module, string? status, DateTime? date, int page, int pageSize, CancellationToken cancellationToken);
    Task<AuditLogDto?> GetByIdAsync(long id, CancellationToken cancellationToken);
}

public sealed class AuditLogService(AppDbContext db) : IAuditLogService
{
    public async Task<AuditLogListResponse> GetAsync(string? search, string? module, string? status, DateTime? date, int page, int pageSize, CancellationToken cancellationToken)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var query = db.AuditLogs.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var value = search.Trim();
            query = query.Where(x => x.Username.Contains(value) || x.Action.Contains(value) || (x.Details != null && x.Details.Contains(value)) || (x.TargetResource != null && x.TargetResource.Contains(value)));
        }

        if (!string.IsNullOrWhiteSpace(module) && Enum.TryParse<AuditModule>(module, true, out var moduleValue))
            query = query.Where(x => x.Module == moduleValue);

        if (!string.IsNullOrWhiteSpace(status) && Enum.TryParse<AuditStatus>(status, true, out var statusValue))
            query = query.Where(x => x.Status == statusValue);

        if (date.HasValue)
        {
            var start = date.Value.Date;
            var end = start.AddDays(1);
            query = query.Where(x => x.CreatedAt >= start && x.CreatedAt < end);
        }

        var total = await query.CountAsync(cancellationToken);
        var data = await query.OrderByDescending(x => x.CreatedAt).ThenByDescending(x => x.Id)
            .Skip((page - 1) * pageSize).Take(pageSize).Select(x => new AuditLogDto
            {
                Id = x.Id,
                User = x.Username,
                Action = x.Action,
                Module = x.Module.ToString(),
                Description = x.Details ?? x.Action,
                DateTime = x.CreatedAt,
                Status = x.Status.ToString(),
                IpAddress = x.IpAddress,
                TargetId = x.TargetResource,
                Details = x.Details
            }).ToListAsync(cancellationToken);

        return new AuditLogListResponse { Data = data, Page = page, PageSize = pageSize, Total = total };
    }

    public async Task<AuditLogDto?> GetByIdAsync(long id, CancellationToken cancellationToken)
    {
        return await db.AuditLogs.AsNoTracking().Where(x => x.Id == id).Select(x => new AuditLogDto
        {
            Id = x.Id,
            User = x.Username,
            Action = x.Action,
            Module = x.Module.ToString(),
            Description = x.Details ?? x.Action,
            DateTime = x.CreatedAt,
            Status = x.Status.ToString(),
            IpAddress = x.IpAddress,
            TargetId = x.TargetResource,
            Details = x.Details
        }).SingleOrDefaultAsync(cancellationToken);
    }
}
