namespace SmartBusTicketing.Api.DTOs;

public sealed class AuditLogDto
{
    public long Id { get; init; }
    public string User { get; init; } = string.Empty;
    public string Action { get; init; } = string.Empty;
    public string Module { get; init; } = "System";
    public string Description { get; init; } = string.Empty;
    public DateTime DateTime { get; init; }
    public string Status { get; init; } = "Success";
    public string? IpAddress { get; init; }
    public string? TargetId { get; init; }
    public string? Details { get; init; }
}

public sealed class AuditLogListResponse
{
    public IReadOnlyList<AuditLogDto> Data { get; init; } = [];
    public int Page { get; init; }
    public int PageSize { get; init; }
    public int Total { get; init; }
}
