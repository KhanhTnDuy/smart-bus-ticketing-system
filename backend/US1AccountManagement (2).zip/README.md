# US1 Backend Only — Account Management & Role Assignment

This ZIP isolates **User Story 1 only**. It does not contain the React frontend or a full database dump. The API uses the existing `smart_bus_ticketing` MySQL database and preserves its numeric `BIGINT` primary key internally. For compatibility with the frontend `User` type, account IDs are serialized as `USR-001`, `USR-002`, etc.

## Frontend contract checked

The supplied frontend defines `User` fields `id`, `username`, `fullName`, `email`, `phone`, `role`, `status`, `createdAt`, optional `avatarUrl`, and optional `department`. Roles supported by the current UI are `ADMIN`, `MANAGER`, `DRIVER`, `PASSENGER`; statuses are `ACTIVE`, `INACTIVE`, `LOCKED`. API responses use those field names and uppercase values.

The current main frontend's `DataContext.tsx` and `AuthContext.tsx` still use mock data and do not call this API. The old `accountApi.ts` also sends spoofable `X-User-Role` headers; this backend intentionally ignores that approach and requires `Authorization: Bearer <token>`. To connect it, frontend API calls must first call `/api/auth/login`, save the returned access token, and send it as a Bearer token. Account creation must include a password; this backend does not generate the insecure default `123456`.

## Before running

1. Confirm the shared MySQL database `smart_bus_ticketing` is running and its `accounts` and `audit_logs` tables already exist.
2. Apply `Migrations/001_AccountManagementFields.sql` once to the existing database. It adds only the fields required by the frontend's US1 model (`status`, `department`, `avatar_url`); it is not a database dump and is not executed automatically by the API.
3. Configure `ConnectionStrings:Default` and set a private JWT signing key of at least 32 UTF-8 bytes using the environment variable `Jwt__Key`. Do not use the sample key in production.
4. Ensure at least one active ADMIN account exists and its `password_hash` was created using BCrypt.
5. From this folder run:

```powershell
dotnet restore
dotnet build
dotnet run
```

Swagger is available at `/swagger`.

## API

- `POST /api/auth/login` — body `{ "identity": "admin", "password": "..." }`; returns `accessToken` and `user`.
- `POST /api/auth/logout` — requires Bearer token; records logout in `audit_logs`.
- `GET /api/accounts?page=1&pageSize=20&search=&role=ALL&status=ALL` — returns an array of frontend `User` objects. Pagination metadata is in `X-Total-Count`, `X-Page`, `X-Page-Size` headers. Maximum page size is 100.
- `GET /api/accounts/{id}` — accepts `USR-001` or numeric IDs.
- `POST /api/accounts` — requires `username`, `fullName`, `email`, `phone`, `role`, `password`; `status`, `department`, `avatarUrl` are optional.
- `PUT /api/accounts/{id}` — partial account update.
- `PATCH /api/accounts/{id}/role` — body `{ "role": "MANAGER" }`.
- `DELETE /api/accounts/{id}` — soft delete by changing status to `INACTIVE`, not physical deletion.

All account management endpoints require an ADMIN JWT. The backend blocks self-role changes, removing the last active ADMIN, and deactivating/reassigning a DRIVER with scheduled/running/delayed trips. It logs account and authentication actions to the existing `audit_logs` table.

## Important limitation

This is a backend-only handoff. Since the current React UI is still backed by mock state, the UI will not start using these APIs until its `DataContext`/`AuthContext` are connected to the API. The create-account form also needs a password field to satisfy the backend's security validation.
