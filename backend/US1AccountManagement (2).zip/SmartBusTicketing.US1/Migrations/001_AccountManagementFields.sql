-- One-time migration for the existing Smart Bus Ticketing accounts table.
-- Run this through the database owner's approved migration process before starting US1.
ALTER TABLE accounts
    ADD COLUMN status ENUM('ACTIVE','INACTIVE','LOCKED') NOT NULL DEFAULT 'ACTIVE' AFTER active,
    ADD COLUMN department VARCHAR(120) NULL AFTER status,
    ADD COLUMN avatar_url VARCHAR(255) NULL AFTER department;

UPDATE accounts
SET status = CASE WHEN active = TRUE THEN 'ACTIVE' ELSE 'INACTIVE' END;
