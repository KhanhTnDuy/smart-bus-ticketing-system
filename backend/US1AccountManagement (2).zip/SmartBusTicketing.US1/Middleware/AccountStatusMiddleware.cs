using System.Security.Claims;
using System.Text.Json;
using SmartBusTicketing.US1.Data;

namespace SmartBusTicketing.US1.Middleware;

public sealed class AccountStatusMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context, AccountRepository repository)
    {
        var path = context.Request.Path.Value ?? "";
        var isAuthEndpoint = path.StartsWith("/api/auth", StringComparison.OrdinalIgnoreCase);
        if (context.User.Identity?.IsAuthenticated == true && !isAuthEndpoint)
        {
            var idText = context.User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (!long.TryParse(idText, out var id))
            {
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                return;
            }
            var account = await repository.GetByIdAsync(id);
            if (account is null || account.Status != "ACTIVE")
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                context.Response.ContentType = "application/json; charset=utf-8";
                await context.Response.WriteAsync(JsonSerializer.Serialize(new { message = "Tài khoản không còn hoạt động hoặc đã bị khóa.", code = "ACCOUNT_INACTIVE" }));
                return;
            }
        }
        await next(context);
    }
}
