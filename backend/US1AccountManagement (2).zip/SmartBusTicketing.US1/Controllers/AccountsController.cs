using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartBusTicketing.US1.Models;
using SmartBusTicketing.US1.Services;

namespace SmartBusTicketing.US1.Controllers;

[ApiController]
[Route("api/accounts")]
[Authorize(Roles = "ADMIN")]
public sealed class AccountsController(AccountService accountService) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] int page = 1, [FromQuery] int pageSize = 20,
        [FromQuery] string? search = null, [FromQuery] string? role = null, [FromQuery] string? status = null)
    {
        try
        {
            var result = await accountService.ListAsync(page, pageSize, search, role, status);
            Response.Headers["X-Total-Count"] = result.TotalCount.ToString();
            Response.Headers["X-Page"] = result.Page.ToString();
            Response.Headers["X-Page-Size"] = result.PageSize.ToString();
            return Ok(result.Items);
        }
        catch (ArgumentException ex) { return BadRequest(new ApiError { Message = ex.Message }); }
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(string id)
    {
        try
        {
            var account = await accountService.GetAsync(id);
            return account is null ? NotFound(new ApiError { Message = "Không tìm thấy tài khoản." }) : Ok(account);
        }
        catch (ArgumentException ex) { return BadRequest(new ApiError { Message = ex.Message }); }
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateAccountRequest request)
    {
        try
        {
            var created = await accountService.CreateAsync(request, ActorName);
            return CreatedAtAction(nameof(Get), new { id = created.Id }, created);
        }
        catch (ArgumentException ex) { return BadRequest(new ApiError { Message = ex.Message }); }
        catch (InvalidOperationException ex) { return Conflict(new ApiError { Message = ex.Message }); }
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(string id, [FromBody] UpdateAccountRequest request)
    {
        if (!long.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var actorId)) return Unauthorized();
        try
        {
            var updated = await accountService.UpdateAsync(id, request, actorId, ActorName);
            return updated is null ? NotFound(new ApiError { Message = "Không tìm thấy tài khoản." }) : Ok(updated);
        }
        catch (ArgumentException ex) { return BadRequest(new ApiError { Message = ex.Message }); }
        catch (InvalidOperationException ex) { return Conflict(new ApiError { Message = ex.Message }); }
    }

    [HttpPatch("{id}/role")]
    public async Task<IActionResult> AssignRole(string id, [FromBody] AssignRoleRequest request)
    {
        if (!long.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var actorId)) return Unauthorized();
        try
        {
            var updated = await accountService.AssignRoleAsync(id, request.Role, actorId, ActorName);
            return Ok(updated);
        }
        catch (ArgumentException ex) { return BadRequest(new ApiError { Message = ex.Message }); }
        catch (KeyNotFoundException ex) { return NotFound(new ApiError { Message = ex.Message }); }
        catch (InvalidOperationException ex) { return Conflict(new ApiError { Message = ex.Message }); }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        if (!long.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var actorId)) return Unauthorized();
        try
        {
            await accountService.SoftDeleteAsync(id, actorId, ActorName);
            return Ok(new { message = "Tài khoản đã được chuyển sang INACTIVE." });
        }
        catch (ArgumentException ex) { return BadRequest(new ApiError { Message = ex.Message }); }
        catch (KeyNotFoundException ex) { return NotFound(new ApiError { Message = ex.Message }); }
        catch (InvalidOperationException ex) { return Conflict(new ApiError { Message = ex.Message }); }
    }

    private string ActorName => User.Identity?.Name ?? "admin";
}
