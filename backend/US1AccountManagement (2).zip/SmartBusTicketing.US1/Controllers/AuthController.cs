using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartBusTicketing.US1.Models;
using SmartBusTicketing.US1.Services;

namespace SmartBusTicketing.US1.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController(AuthService authService) : ControllerBase
{
    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        try { return Ok(await authService.LoginAsync(request, HttpContext.Connection.RemoteIpAddress?.ToString())); }
        catch (UnauthorizedAccessException ex) { return Unauthorized(new ApiError { Message = ex.Message, Code = "AUTH_FAILED" }); }
    }

    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await authService.LogoutAsync(User, HttpContext.Connection.RemoteIpAddress?.ToString());
        return Ok(new { message = "Đăng xuất thành công." });
    }
}
