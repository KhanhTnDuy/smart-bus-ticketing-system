using SmartBusTicketing.US1.Data;
using SmartBusTicketing.US1.Models;

namespace SmartBusTicketing.US1.Services;

public sealed class AccountService(AccountRepository repository)
{
    private static readonly HashSet<string> Roles = ["ADMIN", "MANAGER", "DRIVER", "PASSENGER"];
    private static readonly HashSet<string> Statuses = ["ACTIVE", "INACTIVE", "LOCKED"];

    public Task<PagedResult<AccountDto>> ListAsync(int page, int pageSize, string? search, string? role, string? status)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);
        if (!string.IsNullOrWhiteSpace(role) && role != "ALL" && !Roles.Contains(role)) throw new ArgumentException("Vai trò không hợp lệ.");
        if (!string.IsNullOrWhiteSpace(status) && status != "ALL" && !Statuses.Contains(status)) throw new ArgumentException("Trạng thái không hợp lệ.");
        return repository.GetPagedAsync(page, pageSize, search, role, status);
    }

    public async Task<AccountDto?> GetAsync(string id) => await repository.GetByIdAsync(ParseId(id));

    public async Task<AccountDto> CreateAsync(CreateAccountRequest request, string actor)
    {
        ValidateRole(request.Role);
        ValidateStatus(request.Status);
        var duplicates = await repository.FindDuplicatesAsync(request.Username, request.Email, request.Phone);
        if (duplicates.Username) throw new InvalidOperationException("Tên đăng nhập này đã tồn tại trong hệ thống.");
        if (duplicates.Email) throw new InvalidOperationException("Địa chỉ email này đã được sử dụng.");
        if (duplicates.Phone) throw new InvalidOperationException("Số điện thoại này đã được sử dụng.");
        return await repository.CreateAsync(request, actor);
    }

    public async Task<AccountDto?> UpdateAsync(string id, UpdateAccountRequest request, long actorId, string actor)
    {
        var numericId = ParseId(id);
        if (request.Status is not null) ValidateStatus(request.Status);
        if (request.Role is not null)
        {
            ValidateRole(request.Role);
            var target = await repository.GetByIdAsync(numericId);
            if (target is null) return null;
            if (target.Role != request.Role)
            {
                if (numericId == actorId) throw new InvalidOperationException("Không thể tự thay đổi vai trò của tài khoản đang đăng nhập.");
                if (target.Role == "ADMIN" && request.Role != "ADMIN" && await repository.IsLastActiveAdminAsync(numericId))
                    throw new InvalidOperationException("Không thể hạ quyền Admin cuối cùng trong hệ thống.");
                if (target.Role == "DRIVER" && request.Role != "DRIVER" && await repository.HasActiveTripsAsync(numericId))
                    throw new InvalidOperationException("Không thể đổi vai trò tài xế đang được phân công chuyến chưa hoàn thành.");
            }
        }
        if (request.Email is not null || request.Phone is not null)
        {
            var current = await repository.GetByIdAsync(numericId);
            if (current is null) return null;
            var duplicates = await repository.FindDuplicatesAsync(current.Username, request.Email ?? current.Email, request.Phone ?? current.Phone, numericId);
            if (duplicates.Email) throw new InvalidOperationException("Email này đã được sử dụng bởi tài khoản khác.");
            if (duplicates.Phone) throw new InvalidOperationException("Số điện thoại này đã được sử dụng bởi tài khoản khác.");
        }
        if (request.Status is "INACTIVE" or "LOCKED")
        {
            var current = await repository.GetByIdAsync(numericId);
            if (current?.Role == "ADMIN" && await repository.IsLastActiveAdminAsync(numericId))
                throw new InvalidOperationException("Không thể khóa hoặc vô hiệu hóa Admin cuối cùng.");
            if (current?.Role == "DRIVER" && await repository.HasActiveTripsAsync(numericId))
                throw new InvalidOperationException("Không thể khóa tài xế đang được phân công chuyến chưa hoàn thành.");
        }
        return await repository.UpdateAsync(numericId, request, actor);
    }

    public async Task<AccountDto> AssignRoleAsync(string id, string newRole, long actorId, string actorName)
    {
        var numericId = ParseId(id);
        ValidateRole(newRole);
        if (numericId == actorId) throw new InvalidOperationException("Không thể tự thay đổi vai trò của tài khoản đang đăng nhập.");
        var current = await repository.GetByIdAsync(numericId) ?? throw new KeyNotFoundException("Không tìm thấy tài khoản.");
        if (current.Role == "ADMIN" && newRole != "ADMIN" && await repository.IsLastActiveAdminAsync(numericId))
            throw new InvalidOperationException("Không thể hạ quyền Admin cuối cùng trong hệ thống.");
        if (current.Role == "DRIVER" && newRole != "DRIVER" && await repository.HasActiveTripsAsync(numericId))
            throw new InvalidOperationException("Không thể đổi vai trò tài xế đang được phân công chuyến chưa hoàn thành.");
        var result = await repository.AssignRoleAsync(numericId, newRole, actorName);
        if (!result.Found) throw new KeyNotFoundException("Không tìm thấy tài khoản.");
        return (await repository.GetByIdAsync(numericId))!;
    }

    public async Task SoftDeleteAsync(string id, long actorId, string actorName)
    {
        var numericId = ParseId(id);
        if (numericId == actorId) throw new InvalidOperationException("Bạn không thể xóa chính tài khoản đang đăng nhập.");
        var current = await repository.GetByIdAsync(numericId) ?? throw new KeyNotFoundException("Không tìm thấy tài khoản để xóa.");
        if (current.Role == "ADMIN" && current.Status == "ACTIVE" && await repository.IsLastActiveAdminAsync(numericId))
            throw new InvalidOperationException("Không thể vô hiệu hóa Admin cuối cùng trong hệ thống.");
        if (current.Role == "DRIVER" && await repository.HasActiveTripsAsync(numericId))
            throw new InvalidOperationException("Không thể vô hiệu hóa tài xế đang được phân công chuyến chưa hoàn thành.");
        if (!await repository.SoftDeleteAsync(numericId, actorName)) throw new InvalidOperationException("Tài khoản đã bị vô hiệu hóa hoặc không tồn tại.");
    }

    public static long ParseId(string value)
    {
        var raw = value.Trim();
        if (raw.StartsWith("USR-", StringComparison.OrdinalIgnoreCase)) raw = raw[4..];
        if (!long.TryParse(raw, out var id) || id <= 0) throw new ArgumentException("Mã tài khoản không hợp lệ.");
        return id;
    }

    private static void ValidateRole(string role)
    {
        if (!Roles.Contains(role)) throw new ArgumentException("Vai trò không hợp lệ. Chỉ chấp nhận ADMIN, MANAGER, DRIVER, PASSENGER.");
    }

    private static void ValidateStatus(string status)
    {
        if (!Statuses.Contains(status)) throw new ArgumentException("Trạng thái không hợp lệ.");
    }
}
