using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using SmartBusTicketing.US1.Data;
using SmartBusTicketing.US1.Models;

namespace SmartBusTicketing.US1.Services;

public sealed class AuthService(AccountRepository repository, IConfiguration configuration)
{
    public async Task<LoginResponse> LoginAsync(LoginRequest request, string? ipAddress)
    {
        var account = await repository.FindForLoginAsync(request.Identity);
        if (account is null || !BCrypt.Net.BCrypt.Verify(request.Password, account.Value.PasswordHash))
        {
            if (account is not null)
                await repository.WriteLoginAuditAsync(account.Value.Id, account.Value.Username, "LOGIN", "FAILURE", ipAddress, "Invalid password");
            throw new UnauthorizedAccessException("Tài khoản hoặc mật khẩu không chính xác.");
        }
        if (account.Value.Status != "ACTIVE")
        {
            await repository.WriteLoginAuditAsync(account.Value.Id, account.Value.Username, "LOGIN", "WARNING", ipAddress, "Account is not active");
            throw new UnauthorizedAccessException(account.Value.Status == "LOCKED" ? "Tài khoản đang bị khóa." : "Tài khoản đang không hoạt động.");
        }

        var expires = DateTime.UtcNow.AddHours(2);
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, account.Value.Id.ToString()),
            new Claim(ClaimTypes.NameIdentifier, account.Value.Id.ToString()),
            new Claim(ClaimTypes.Name, account.Value.Username),
            new Claim("name", account.Value.Username),
            new Claim("role", account.Value.Role),
            new Claim(ClaimTypes.Role, account.Value.Role)
        };
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]!));
        var token = new JwtSecurityToken(configuration["Jwt:Issuer"], configuration["Jwt:Audience"], claims,
            expires: expires, signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));
        await repository.WriteLoginAuditAsync(account.Value.Id, account.Value.Username, "LOGIN", "SUCCESS", ipAddress, null);
        return new LoginResponse
        {
            AccessToken = new JwtSecurityTokenHandler().WriteToken(token), ExpiresAt = expires,
            User = new AccountDto
            {
                Id = $"USR-{account.Value.Id:D3}", Username = account.Value.Username, FullName = account.Value.FullName,
                Email = account.Value.Email, Phone = account.Value.Phone, Role = account.Value.Role, Status = account.Value.Status,
                CreatedAt = account.Value.CreatedAt.ToString("yyyy-MM-dd HH:mm:ss"), Department = account.Value.Department, AvatarUrl = account.Value.AvatarUrl
            }
        };
    }

    public async Task LogoutAsync(ClaimsPrincipal user, string? ipAddress)
    {
        var idText = user.FindFirstValue(ClaimTypes.NameIdentifier);
        var username = user.Identity?.Name ?? "unknown";
        if (long.TryParse(idText, out var id)) await repository.WriteLoginAuditAsync(id, username, "LOGOUT", "SUCCESS", ipAddress, null);
    }
}
