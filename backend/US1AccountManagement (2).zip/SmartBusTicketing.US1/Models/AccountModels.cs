using System.ComponentModel.DataAnnotations;

namespace SmartBusTicketing.US1.Models;

public sealed class AccountDto
{
    public string Id { get; init; } = "";
    public string Username { get; init; } = "";
    public string FullName { get; init; } = "";
    public string Email { get; init; } = "";
    public string Phone { get; init; } = "";
    public string Role { get; init; } = "PASSENGER";
    public string Status { get; init; } = "ACTIVE";
    public string CreatedAt { get; init; } = "";
    public string? AvatarUrl { get; init; }
    public string? Department { get; init; }
}

public sealed class CreateAccountRequest
{
    [Required, StringLength(50, MinimumLength = 3)] public string Username { get; init; } = "";
    [Required, StringLength(100, MinimumLength = 2)] public string FullName { get; init; } = "";
    [Required, EmailAddress, StringLength(100)] public string Email { get; init; } = "";
    [Required, RegularExpression("^[0-9]{9,11}$")] public string Phone { get; init; } = "";
    [Required, RegularExpression("^(ADMIN|MANAGER|DRIVER|PASSENGER)$")] public string Role { get; init; } = "PASSENGER";
    [RegularExpression("^(ACTIVE|INACTIVE|LOCKED)$")] public string Status { get; init; } = "ACTIVE";
    [Required, MinLength(8), RegularExpression("^(?=.*[A-Za-z])(?=.*[0-9]).+$", ErrorMessage = "Password must contain at least one letter and one number.")] public string Password { get; init; } = "";
    [StringLength(255)] public string? AvatarUrl { get; init; }
    [StringLength(120)] public string? Department { get; init; }
}

public sealed class UpdateAccountRequest
{
    [StringLength(100, MinimumLength = 2)] public string? FullName { get; init; }
    [EmailAddress, StringLength(100)] public string? Email { get; init; }
    [RegularExpression("^[0-9]{9,11}$")] public string? Phone { get; init; }
    [RegularExpression("^(ADMIN|MANAGER|DRIVER|PASSENGER)$")] public string? Role { get; init; }
    [RegularExpression("^(ACTIVE|INACTIVE|LOCKED)$")] public string? Status { get; init; }
    [StringLength(255)] public string? AvatarUrl { get; init; }
    [StringLength(120)] public string? Department { get; init; }
}

public sealed class AssignRoleRequest
{
    [Required, RegularExpression("^(ADMIN|MANAGER|DRIVER|PASSENGER)$")] public string Role { get; init; } = "";
}

public sealed class LoginRequest
{
    [Required] public string Identity { get; init; } = "";
    [Required] public string Password { get; init; } = "";
}

public sealed class LoginResponse
{
    public string AccessToken { get; init; } = "";
    public string TokenType { get; init; } = "Bearer";
    public DateTime ExpiresAt { get; init; }
    public AccountDto User { get; init; } = new();
}

public sealed class PagedResult<T>
{
    public IReadOnlyList<T> Items { get; init; } = [];
    public int Page { get; init; }
    public int PageSize { get; init; }
    public long TotalCount { get; init; }
}

public sealed class ApiError
{
    public string Message { get; init; } = "";
    public string? Code { get; init; }
}
