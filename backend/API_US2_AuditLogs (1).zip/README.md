# US2

US2 - Audit Logs: access/activity log listing and details.

Project path: `backend/SmartBusTicketing.Api/`
This ZIP is a self-contained copy of the current API structure with the selected User Story controllers.
